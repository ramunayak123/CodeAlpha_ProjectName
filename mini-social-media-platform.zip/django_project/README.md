# Mini Social Media Platform (Django + SQLite)

A beginner-friendly, production-ready Mini Social Media Platform inspired by Instagram, built with Python Django, SQLite, HTML5, CSS3, and JavaScript.

---

## 📁 Project Folder Structure

```text
django_project/
├── manage.py
├── requirements.txt
├── README.md
├── db.sqlite3                # SQLite database (generated after migrations)
├── mini_social/              # Project settings & root routing
│   ├── __init__.py
│   ├── settings.py           # SQLite, Auth, Media & Static setup
│   ├── urls.py               # Main URL dispatcher
│   └── wsgi.py
├── core/                     # Main Social Application
│   ├── __init__.py
│   ├── admin.py              # Django Admin registrations
│   ├── apps.py               # App configuration & signal imports
│   ├── forms.py              # UserRegister, Profile, Post & Comment forms
│   ├── models.py             # User, Profile, Post, Comment, Like, Follow
│   ├── signals.py            # Auto Profile creation on user signup
│   ├── urls.py               # Core application routes
│   ├── views.py              # Feed, Profile, CRUD, Likes, Comments, Follow
│   └── migrations/
│       ├── __init__.py
│       └── 0001_initial.py   # Database migrations
├── templates/                # HTML5 Templates
│   ├── base.html             # Base layout with navbar & flash alerts
│   └── core/
│       ├── home.html         # Main feed & suggested creators
│       ├── explore.html      # Search & tags discovery
│       ├── profile.html      # User profile, stats & posts grid
│       ├── create_post.html  # Image upload & filter picker
│       ├── login.html        # Authentication login
│       └── register.html     # User registration form
└── static/
    ├── css/style.css         # Styling & photo filters
    └── js/main.js            # AJAX likes & dynamic UI
```

---

## 🗄️ Database Models & Relationships

1. **User** (`django.contrib.auth.models.User`): Standard Django User model (id, username, email, password, first_name).
2. **Profile** (`OneToOneField(User)`): Stores user avatars, bio, website link, location, and verified creator status. Automatically created via Django `post_save` signals.
3. **Post** (`ForeignKey(User)`): Stores image file, caption, location tag, filter style, and timestamps.
4. **Comment** (`ForeignKey(Post)`, `ForeignKey(User)`): Stores text and creation timestamp with cascaded deletion.
5. **Like** (`ForeignKey(Post)`, `ForeignKey(User)`): Enforces `unique_together = ('post', 'user')` to prevent duplicate likes.
6. **Follow** (`ForeignKey(User, follower)`, `ForeignKey(User, following)`): Enforces `unique_together` and validation preventing users from following themselves.

---

## 🚀 Step-by-Step Installation & Setup Instructions

### 1. Prerequisites
- Python 3.10+ installed
- `pip` package manager

### 2. Create and Activate a Virtual Environment
```bash
# Navigate to the project root
cd django_project

# Create a virtual environment
python3 -m venv venv

# Activate on Linux/macOS:
source venv/bin/activate

# Or activate on Windows:
# venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Create an Admin Superuser
```bash
python manage.py createsuperuser
# Enter your desired username (e.g. admin), email, and password.
```

### 6. Run the Development Server
```bash
python manage.py runserver
```
Visit **http://127.0.0.1:8000** in your browser.

---

## 🧪 Testing Instructions for All Features

1. **User Registration & Login**:
   - Navigate to `/register/`. Fill in username, email, and password.
   - Verify that duplicate usernames/emails trigger validation errors.
   - Verify automatic login upon successful sign up.
   - Test `/logout/` and then log in again at `/login/`.

2. **User Profiles**:
   - Click your profile image in the top navbar and select **Profile**.
   - View your post count, follower count, and following count.
   - Click **Edit Profile** to upload a new profile picture and update your bio and location.

3. **Publishing Posts**:
   - Click the **+ Create** button in the top navbar.
   - Select an image file, choose a filter (e.g. *Clarendon* or *Moon*), write a caption with `#tags`, and add a location.
   - Click **Publish Post**; verify the post appears immediately at the top of the Home feed.

4. **Like System**:
   - Click the heart icon on any post.
   - Notice the heart fills red and the like count increments by 1.
   - Click again to unlike; verify count decrements.
   - Check that duplicate likes are prevented at both the database constraint and view levels.

5. **Comments System**:
   - Type a comment into the input bar below any post and submit.
   - Verify the comment appears with your username.
   - Click the delete button on your own comment to verify deletion.
   - Verify you cannot delete other users' comments.

6. **Follow System**:
   - Go to the **Explore** page or look at **Suggested For You** on the Home feed.
   - Click **Follow** on another creator.
   - Verify the button updates to "Following" and the target user's follower count increments.
   - Switch the Home feed filter to **Following Only** to see only posts from creators you follow.
