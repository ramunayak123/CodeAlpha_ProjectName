from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile, Post, Comment

class UserRegisterForm(UserCreationForm):
    """
    Form for registering a new user with email, username, and full name.
    """
    email = forms.EmailField(required=True, help_text="Required. Inform a valid email address.")
    first_name = forms.CharField(max_length=30, required=True, label="Full Name")

    class Meta:
        model = User
        fields = ['username', 'first_name', 'email']

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("This email address is already in use.")
        return email


class UserUpdateForm(forms.ModelForm):
    """
    Form for updating basic account info (username, email, full name).
    """
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['first_name', 'username', 'email']


class ProfileUpdateForm(forms.ModelForm):
    """
    Form for updating profile picture, bio, website, and location.
    """
    class Meta:
        model = Profile
        fields = ['avatar', 'bio', 'website', 'location']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Write your bio...'}),
            'website': forms.URLInput(attrs={'placeholder': 'https://yourwebsite.com'}),
            'location': forms.TextInput(attrs={'placeholder': 'City, Country'}),
        }


class PostCreateForm(forms.ModelForm):
    """
    Form for creating a new photo post with caption and location.
    """
    class Meta:
        model = Post
        fields = ['image', 'caption', 'location', 'filter_style']
        widgets = {
            'caption': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Write a caption... #travel #photography'}),
            'location': forms.TextInput(attrs={'placeholder': 'Add location (e.g. Kyoto, Japan)'}),
            'filter_style': forms.Select(choices=[
                ('normal', 'Normal'),
                ('clarendon', 'Clarendon (Vibrant & Contrast)'),
                ('vintage', 'Vintage (Warm Sepia)'),
                ('moon', 'Moon (B&W High-Contrast)'),
                ('warm', 'Warm (Sun-kissed Golden)'),
                ('vivid', 'Vivid (Saturated Pop)'),
                ('cinema', 'Cinema (Moody Film)'),
            ]),
        }


class CommentForm(forms.ModelForm):
    """
    Form for creating a comment on a post.
    """
    class Meta:
        model = Comment
        fields = ['text']
        widgets = {
            'text': forms.TextInput(attrs={'placeholder': 'Add a comment...', 'autocomplete': 'off'}),
        }
