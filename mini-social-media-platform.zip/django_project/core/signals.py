from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver
from .models import Profile

@receiver(post_save, sender=User)
def create_or_save_user_profile(sender, instance, created, **kwargs):
    """
    Automatically creates and saves a Profile object whenever a new User is created.
    """
    if created:
        Profile.objects.create(user=instance)
    else:
        # Avoid crashing if profile didn't exist previously
        if hasattr(instance, 'profile'):
            instance.profile.save()
