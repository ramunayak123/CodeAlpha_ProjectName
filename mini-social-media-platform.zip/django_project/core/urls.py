from django.urls import path
from . import views

urlpatterns = [
    # Feed & Explore
    path('', views.home_view, name='home'),
    path('explore/', views.explore_view, name='explore'),

    # Authentication
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('password-change/', views.change_password_view, name='password_change'),

    # User Profile
    path('profile/<str:username>/', views.profile_view, name='profile'),
    path('profile/edit/details/', views.edit_profile_view, name='edit_profile'),
    path('profile/<str:username>/followers/', views.followers_list_view, name='followers_list'),
    path('profile/<str:username>/following/', views.following_list_view, name='following_list'),

    # Posts CRUD
    path('post/create/', views.create_post_view, name='create_post'),
    path('post/<int:post_id>/edit/', views.edit_post_view, name='edit_post'),
    path('post/<int:post_id>/delete/', views.delete_post_view, name='delete_post'),

    # Interactions: Likes, Comments & Follow
    path('post/<int:post_id>/like/', views.toggle_like_view, name='toggle_like'),
    path('post/<int:post_id>/comment/', views.add_comment_view, name='add_comment'),
    path('comment/<int:comment_id>/delete/', views.delete_comment_view, name='delete_comment'),
    path('user/<int:user_id>/follow/', views.toggle_follow_view, name='toggle_follow'),
]
