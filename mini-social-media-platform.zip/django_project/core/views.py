from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse, HttpResponseForbidden
from django.db.models import Q

from .models import Post, Profile, Comment, Like, Follow
from .forms import (
    UserRegisterForm,
    UserUpdateForm,
    ProfileUpdateForm,
    PostCreateForm,
    CommentForm
)

def register_view(request):
    """Register a new user account."""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, f"Welcome @{user.username}! Your account has been created.")
            login(request, user)
            return redirect('home')
    else:
        form = UserRegisterForm()

    return render(request, 'core/register.html', {'form': form, 'title': 'Register'})


def login_view(request):
    """Authenticate and log in an existing user."""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as @{username}.")
                next_url = request.GET.get('next', 'home')
                return redirect(next_url)
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()

    return render(request, 'core/login.html', {'form': form, 'title': 'Login'})


@login_required
def logout_view(request):
    """Log out current user."""
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('login')


@login_required
def home_view(request):
    """
    Home Feed: Displays posts with stories and suggested users.
    Supports filtering by 'following' or 'all'.
    """
    feed_filter = request.GET.get('feed', 'all')
    user = request.user

    if feed_filter == 'following':
        following_user_ids = user.following.values_list('following_id', flat=True)
        posts = Post.objects.filter(
            Q(author_id__in=following_user_ids) | Q(author=user)
        ).select_related('author', 'author__profile').prefetch_related('likes', 'comments')
    else:
        posts = Post.objects.all().select_related('author', 'author__profile').prefetch_related('likes', 'comments')

    # Suggested users (excluding current user and already followed users)
    already_following = user.following.values_list('following_id', flat=True)
    suggested_users = User.objects.exclude(id=user.id).exclude(id__in=already_following)[:5]

    comment_form = CommentForm()

    context = {
        'posts': posts,
        'suggested_users': suggested_users,
        'feed_filter': feed_filter,
        'comment_form': comment_form,
        'title': 'Feed',
    }
    return render(request, 'core/home.html', context)


@login_required
def explore_view(request):
    """Explore page: Discover other users, search posts by caption/tags/author."""
    query = request.GET.get('q', '').strip()
    tag = request.GET.get('tag', '').strip()

    posts = Post.objects.all().select_related('author', 'author__profile')

    if query:
        posts = posts.filter(
            Q(caption__icontains=query) |
            Q(author__username__icontains=query) |
            Q(location__icontains=query)
        )
    elif tag:
        posts = posts.filter(caption__icontains=f"#{tag}")

    users = []
    if query:
        users = User.objects.filter(
            Q(username__icontains=query) | Q(first_name__icontains=query)
        ).exclude(id=request.user.id)[:6]

    context = {
        'posts': posts,
        'users': users,
        'query': query,
        'tag': tag,
        'title': 'Explore',
    }
    return render(request, 'core/explore.html', context)


@login_required
def profile_view(request, username):
    """User Profile: Displays user stats, bio, and posts grid."""
    target_user = get_object_or_404(User, username=username)
    profile = get_object_or_404(Profile, user=target_user)
    user_posts = target_user.posts.all().select_related('author')

    is_following = False
    if request.user.is_authenticated and request.user != target_user:
        is_following = Follow.objects.filter(follower=request.user, following=target_user).exists()

    context = {
        'target_user': target_user,
        'profile': profile,
        'posts': user_posts,
        'is_following': is_following,
        'is_own_profile': (request.user == target_user),
        'title': f"@{target_user.username}",
    }
    return render(request, 'core/profile.html', context)


@login_required
def edit_profile_view(request):
    """Edit Profile Details and Profile Picture."""
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, "Your profile has been updated successfully!")
            return redirect('profile', username=request.user.username)
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'user_form': user_form,
        'profile_form': profile_form,
        'title': 'Edit Profile',
    }
    return render(request, 'core/edit_profile.html', context)


@login_required
def change_password_view(request):
    """Change Password View with validation."""
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Keep the user logged in
            messages.success(request, "Your password has been changed successfully!")
            return redirect('profile', username=request.user.username)
        else:
            messages.error(request, "Please correct the error below.")
    else:
        form = PasswordChangeForm(request.user)

    return render(request, 'core/change_password.html', {'form': form, 'title': 'Change Password'})


@login_required
def create_post_view(request):
    """Upload an image and publish a new post."""
    if request.method == 'POST':
        form = PostCreateForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, "Post published successfully!")
            return redirect('home')
    else:
        form = PostCreateForm()

    return render(request, 'core/create_post.html', {'form': form, 'title': 'Create Post'})


@login_required
def edit_post_view(request, post_id):
    """Edit post caption."""
    post = get_object_or_404(Post, id=post_id)
    if post.author != request.user:
        return HttpResponseForbidden("You are not allowed to edit this post.")

    if request.method == 'POST':
        caption = request.POST.get('caption', '')
        location = request.POST.get('location', '')
        post.caption = caption
        post.location = location
        post.save()
        messages.success(request, "Post updated!")
        return redirect('home')

    return render(request, 'core/edit_post.html', {'post': post, 'title': 'Edit Post'})


@login_required
def delete_post_view(request, post_id):
    """Delete a post (only allowed for post author)."""
    post = get_object_or_404(Post, id=post_id)
    if post.author != request.user:
        return HttpResponseForbidden("You are not allowed to delete this post.")

    if request.method == 'POST':
        post.delete()
        messages.success(request, "Post deleted successfully.")
        return redirect('profile', username=request.user.username)

    return render(request, 'core/delete_post_confirm.html', {'post': post})


@login_required
def toggle_like_view(request, post_id):
    """Toggle Like/Unlike on a post. Supports both AJAX and Form POST."""
    post = get_object_or_404(Post, id=post_id)
    like_qs = Like.objects.filter(post=post, user=request.user)

    if like_qs.exists():
        like_qs.delete()
        liked = False
    else:
        Like.objects.create(post=post, user=request.user)
        liked = True

    if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json':
        return JsonResponse({
            'liked': liked,
            'likes_count': post.likes_count,
        })

    return redirect(request.META.get('HTTP_REFERER', 'home'))


@login_required
def add_comment_view(request, post_id):
    """Add a comment to a post."""
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        text = request.POST.get('text', '').strip()
        if text:
            comment = Comment.objects.create(post=post, author=request.user, text=text)
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({
                    'id': comment.id,
                    'author': comment.author.username,
                    'text': comment.text,
                    'created_at': comment.created_at.strftime('%b %d, %Y, %I:%M %p')
                })
            messages.success(request, "Comment added.")

    return redirect(request.META.get('HTTP_REFERER', 'home'))


@login_required
def delete_comment_view(request, comment_id):
    """Delete a comment (only allowed for author or post author)."""
    comment = get_object_or_404(Comment, id=comment_id)
    if comment.author != request.user and comment.post.author != request.user:
        return HttpResponseForbidden("You do not have permission to delete this comment.")

    comment.delete()
    messages.info(request, "Comment deleted.")
    return redirect(request.META.get('HTTP_REFERER', 'home'))


@login_required
def toggle_follow_view(request, user_id):
    """Toggle Follow/Unfollow user. Prevents self-following."""
    target_user = get_object_or_404(User, id=user_id)
    if target_user == request.user:
        messages.error(request, "You cannot follow yourself.")
        return redirect('profile', username=target_user.username)

    follow_qs = Follow.objects.filter(follower=request.user, following=target_user)
    if follow_qs.exists():
        follow_qs.delete()
        following = False
        messages.info(request, f"Unfollowed @{target_user.username}.")
    else:
        Follow.objects.create(follower=request.user, following=target_user)
        following = True
        messages.success(request, f"Now following @{target_user.username}!")

    if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json':
        return JsonResponse({
            'following': following,
            'followers_count': target_user.followers.count(),
        })

    return redirect(request.META.get('HTTP_REFERER', 'profile', username=target_user.username))


@login_required
def followers_list_view(request, username):
    """List followers of a user."""
    user = get_object_or_404(User, username=username)
    followers = user.followers.select_related('follower', 'follower__profile')
    return render(request, 'core/user_list.html', {
        'title': f"Followers of @{user.username}",
        'users_list': [f.follower for f in followers],
    })


@login_required
def following_list_view(request, username):
    """List users followed by this user."""
    user = get_object_or_404(User, username=username)
    following = user.following.select_related('following', 'following__profile')
    return render(request, 'core/user_list.html', {
        'title': f"Following by @{user.username}",
        'users_list': [f.following for f in following],
    })
