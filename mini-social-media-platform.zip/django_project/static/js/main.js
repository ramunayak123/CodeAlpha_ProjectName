// MiniSocial client-side JavaScript for AJAX Likes and Comments
document.addEventListener('DOMContentLoaded', () => {
    // Handle AJAX Likes without page reload
    document.querySelectorAll('.like-form').forEach(form => {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const postId = form.dataset.postId;
            const csrfToken = form.querySelector('[name=csrfmiddlewaretoken]').value;
            const url = form.action;

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': csrfToken,
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    const card = document.getElementById(`post-${postId}`);
                    if (card) {
                        const likesText = card.querySelector('.likes-count-text');
                        if (likesText) {
                            likesText.textContent = `${data.likes_count} likes`;
                        }
                        const likeIcon = form.querySelector('i');
                        if (likeIcon) {
                            if (data.liked) {
                                likeIcon.className = 'bi bi-heart-fill text-danger';
                            } else {
                                likeIcon.className = 'bi bi-heart text-danger';
                            }
                        }
                    }
                }
            } catch (err) {
                console.error("Error toggling like:", err);
                form.submit(); // fallback to normal form post
            }
        });
    });
});
