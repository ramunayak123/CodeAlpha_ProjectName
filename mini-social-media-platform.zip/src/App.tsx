/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SocialProvider, useSocial } from './context/SocialContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { HomeFeed } from './components/HomeFeed';
import { ExplorePage } from './components/ExplorePage';
import { ProfileView } from './components/ProfileView';
import { CreatePostModal } from './components/CreatePostModal';
import { EditProfileModal } from './components/EditProfileModal';
import { AuthModal } from './components/AuthModal';
import { FollowListModal } from './components/FollowListModal';
import { PostDetailModal } from './components/PostDetailModal';
import { DjangoCodeHub } from './components/DjangoCodeHub';

const MainLayout: React.FC = () => {
  const {
    currentView,
    currentUser,
    selectedProfileUserId,
    selectedPostId,
    setSelectedPostId,
  } = useSocial();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);

  const [followModal, setFollowModal] = useState<{
    isOpen: boolean;
    userId: string;
    type: 'followers' | 'following';
    title: string;
  }>({
    isOpen: false,
    userId: '',
    type: 'followers',
    title: '',
  });

  const handleOpenFollowers = (userId: string) => {
    setFollowModal({
      isOpen: true,
      userId,
      type: 'followers',
      title: 'Followers',
    });
  };

  const handleOpenFollowing = (userId: string) => {
    setFollowModal({
      isOpen: true,
      userId,
      type: 'following',
      title: 'Following',
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20 md:pb-8 flex flex-col">
      {/* Top Navigation */}
      <Navbar
        onOpenCreate={() => setIsCreateOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomeFeed
            onOpenCreate={() => setIsCreateOpen(true)}
            onOpenDetail={(postId) => setSelectedPostId(postId)}
            onOpenAuth={() => setIsAuthOpen(true)}
          />
        )}

        {currentView === 'explore' && (
          <ExplorePage
            onOpenDetail={(postId) => setSelectedPostId(postId)}
          />
        )}

        {currentView === 'profile' && (
          <ProfileView
            userId={selectedProfileUserId || currentUser?.id || 'user-1'}
            onOpenDetail={(postId) => setSelectedPostId(postId)}
            onOpenEditProfile={() => setIsEditProfileOpen(true)}
            onOpenFollowers={handleOpenFollowers}
            onOpenFollowing={handleOpenFollowing}
          />
        )}

        {currentView === 'edit-profile' && (
          <ProfileView
            userId={currentUser?.id || 'user-1'}
            onOpenDetail={(postId) => setSelectedPostId(postId)}
            onOpenEditProfile={() => setIsEditProfileOpen(true)}
            onOpenFollowers={handleOpenFollowers}
            onOpenFollowing={handleOpenFollowing}
          />
        )}

        {currentView === 'django-code' && <DjangoCodeHub />}

        {currentView === 'auth' && (
          <HomeFeed
            onOpenCreate={() => setIsCreateOpen(true)}
            onOpenDetail={(postId) => setSelectedPostId(postId)}
            onOpenAuth={() => setIsAuthOpen(true)}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav onOpenCreate={() => setIsCreateOpen(true)} />

      {/* Modals */}
      <CreatePostModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
      />

      <AuthModal
        isOpen={isAuthOpen || currentView === 'auth'}
        onClose={() => setIsAuthOpen(false)}
      />

      <EditProfileModal
        isOpen={isEditProfileOpen || currentView === 'edit-profile'}
        onClose={() => setIsEditProfileOpen(false)}
      />

      <FollowListModal
        isOpen={followModal.isOpen}
        onClose={() => setFollowModal((prev) => ({ ...prev, isOpen: false }))}
        userId={followModal.userId}
        type={followModal.type}
        title={followModal.title}
      />

      <PostDetailModal
        postId={selectedPostId}
        onClose={() => setSelectedPostId(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <SocialProvider>
      <MainLayout />
    </SocialProvider>
  );
}
