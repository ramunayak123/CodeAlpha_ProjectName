import React from 'react';
import { useSocial } from '../context/SocialContext';
import { Home, Compass, PlusSquare, Code2, User } from 'lucide-react';

interface BottomNavProps {
  onOpenCreate: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ onOpenCreate }) => {
  const { currentView, setCurrentView, currentUser, openUserProfile } = useSocial();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-white/95 backdrop-blur-md border-t border-slate-200 h-14 px-4 flex items-center justify-around">
      <button
        onClick={() => setCurrentView('home')}
        className={`flex flex-col items-center justify-center p-1 ${
          currentView === 'home' ? 'text-rose-600' : 'text-slate-500'
        }`}
        title="Home"
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px] font-medium mt-0.5">Home</span>
      </button>

      <button
        onClick={() => setCurrentView('explore')}
        className={`flex flex-col items-center justify-center p-1 ${
          currentView === 'explore' ? 'text-rose-600' : 'text-slate-500'
        }`}
        title="Explore"
      >
        <Compass className="w-5 h-5" />
        <span className="text-[10px] font-medium mt-0.5">Explore</span>
      </button>

      <button
        onClick={onOpenCreate}
        className="flex flex-col items-center justify-center p-1 text-slate-900"
        title="Create"
      >
        <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center -mt-2 shadow-sm">
          <PlusSquare className="w-4 h-4" />
        </div>
        <span className="text-[10px] font-medium mt-0.5">Post</span>
      </button>

      <button
        onClick={() => setCurrentView('django-code')}
        className={`flex flex-col items-center justify-center p-1 ${
          currentView === 'django-code' ? 'text-emerald-600' : 'text-slate-500'
        }`}
        title="Django"
      >
        <Code2 className="w-5 h-5" />
        <span className="text-[10px] font-medium mt-0.5">Django</span>
      </button>

      <button
        onClick={() => {
          if (currentUser) {
            openUserProfile(currentUser.id);
          } else {
            setCurrentView('auth');
          }
        }}
        className={`flex flex-col items-center justify-center p-1 ${
          currentView === 'profile' ? 'text-rose-600' : 'text-slate-500'
        }`}
        title="Profile"
      >
        <User className="w-5 h-5" />
        <span className="text-[10px] font-medium mt-0.5">Profile</span>
      </button>
    </div>
  );
};
