import React, { useState, useRef } from 'react';
import { useSocial } from '../context/SocialContext';
import { PRESET_IMAGES } from '../data/seedData';
import {
  X,
  Upload,
  Image as ImageIcon,
  MapPin,
  Sparkles,
  Check,
  Camera,
} from 'lucide-react';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const FILTERS = [
  { id: 'filter-normal', label: 'Normal' },
  { id: 'filter-clarendon', label: 'Clarendon' },
  { id: 'filter-vintage', label: 'Vintage' },
  { id: 'filter-moon', label: 'Moon (B&W)' },
  { id: 'filter-warm', label: 'Warm' },
  { id: 'filter-vivid', label: 'Vivid' },
  { id: 'filter-cinema', label: 'Cinema' },
  { id: 'filter-retro', label: 'Retro' },
];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { createPost, currentUser } = useSocial();

  const [imageUrl, setImageUrl] = useState<string>('');
  const [selectedFilter, setSelectedFilter] = useState<string>('filter-normal');
  const [caption, setCaption] = useState<string>('');
  const [location, setLocation] = useState<string>('');
  const [step, setStep] = useState<'upload' | 'edit'>('upload');
  const [uploadSource, setUploadSource] = useState<'preset' | 'file'>('file');

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setImageUrl(reader.result);
          setStep('edit');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPreset = (url: string) => {
    setImageUrl(url);
    setStep('edit');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrl) return;

    createPost({
      imageUrl,
      filter: selectedFilter,
      caption,
      location,
    });

    // Reset & close
    setImageUrl('');
    setSelectedFilter('filter-normal');
    setCaption('');
    setLocation('');
    setStep('upload');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <Camera className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">
              {step === 'upload' ? 'Create New Post' : 'Edit & Publish Photo'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {step === 'edit' && (
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="text-xs text-slate-500 hover:text-slate-800 font-medium px-2 py-1 rounded-md hover:bg-slate-100"
              >
                Back
              </button>
            )}
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {step === 'upload' ? (
          <div className="p-6 overflow-y-auto">
            {/* Upload Method Tabs */}
            <div className="flex items-center justify-center gap-2 mb-6">
              <button
                type="button"
                onClick={() => setUploadSource('file')}
                className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
                  uploadSource === 'file'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Upload from Device
              </button>
              <button
                type="button"
                onClick={() => setUploadSource('preset')}
                className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
                  uploadSource === 'preset'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Sample Photo Gallery
              </button>
            </div>

            {uploadSource === 'file' ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-rose-400 rounded-3xl p-10 text-center cursor-pointer bg-slate-50 hover:bg-rose-50/30 transition-all flex flex-col items-center justify-center"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <div className="w-14 h-14 rounded-2xl bg-white shadow-xs border border-slate-200 text-rose-500 flex items-center justify-center mb-4">
                  <Upload className="w-7 h-7" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  Drag and drop photos here, or click to browse
                </h4>
                <p className="text-xs text-slate-500 mb-4">
                  Supports JPEG, PNG, GIF, WebP (up to 10MB)
                </p>
                <button
                  type="button"
                  className="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-xl shadow-xs pointer-events-none"
                >
                  Select from Computer
                </button>
              </div>
            ) : (
              <div>
                <p className="text-xs text-slate-500 mb-3">
                  Click any sample image to test filters, captions, and publishing instantly:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {PRESET_IMAGES.map((img) => (
                    <div
                      key={img.url}
                      onClick={() => handleSelectPreset(img.url)}
                      className="group relative aspect-square rounded-2xl overflow-hidden border border-slate-200 cursor-pointer shadow-xs hover:ring-2 hover:ring-rose-500 transition-all"
                    >
                      <img
                        src={img.url}
                        alt={img.label}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-2.5">
                        <span className="text-[11px] font-bold text-white">
                          {img.label}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Step 2: Edit & Details */
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Photo Preview with Selected Filter */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Photo Preview
                </label>
                <div className="relative aspect-square rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 shadow-xs mb-3">
                  <img
                    src={imageUrl}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover ${selectedFilter}`}
                  />
                  <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-xs rounded text-[10px] font-semibold text-white">
                    {FILTERS.find((f) => f.id === selectedFilter)?.label}
                  </div>
                </div>

                {/* Filter Selector Carousel */}
                <label className="text-[11px] font-bold text-slate-700 block mb-1.5 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-rose-500" />
                  Instagram Photo Filters
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {FILTERS.map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setSelectedFilter(f.id)}
                      className={`flex flex-col items-center p-1 rounded-xl border text-[10px] font-medium transition-all ${
                        selectedFilter === f.id
                          ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/30'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-lg overflow-hidden mb-1">
                        <img
                          src={imageUrl}
                          alt=""
                          referrerPolicy="no-referrer"
                          className={`w-full h-full object-cover ${f.id}`}
                        />
                      </div>
                      <span className="truncate max-w-[56px] text-slate-700">
                        {f.label.split(' ')[0]}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Caption and Location */}
              <div className="flex flex-col justify-between">
                <div className="space-y-4">
                  {/* Author Header */}
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-xs font-bold text-slate-900">
                      @{currentUser?.username || 'you'}
                    </span>
                  </div>

                  {/* Caption */}
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Caption
                    </label>
                    <textarea
                      value={caption}
                      onChange={(e) => setCaption(e.target.value)}
                      placeholder="Write an engaging caption... Add hashtags like #travel, #photography, #foodie"
                      rows={4}
                      className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 text-slate-800"
                    />
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                      <span>Add tags to boost explore discovery</span>
                      <span className="tabular-nums">{caption.length}/2200</span>
                    </div>

                    {/* Quick hashtag suggestions */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {['#photography', '#wanderlust', '#minimalism', '#art'].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => setCaption((prev) => (prev ? `${prev} ${tag}` : tag))}
                          className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[10px] font-medium transition-colors"
                        >
                          + {tag}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Location Tag */}
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Add Location
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="e.g. Kyoto, Japan or Central Park, NY"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 text-slate-800"
                      />
                    </div>
                  </div>
                </div>

                {/* Submit button */}
                <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>Publish Post</span>
                  </button>
                </div>
              </div>

            </div>
          </form>
        )}
      </div>
    </div>
  );
};
