import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  FileCode,
  Folder,
  Terminal,
  Database,
  Layers,
  BookOpen,
  ArrowRight,
  ExternalLink,
  Sparkles,
} from 'lucide-react';

interface CodeFile {
  path: string;
  name: string;
  category: 'models' | 'views' | 'forms' | 'urls' | 'config' | 'migrations' | 'templates' | 'docs';
  description: string;
  content: string;
}

const DJANGO_FILES: CodeFile[] = [
  {
    path: 'core/models.py',
    name: 'models.py',
    category: 'models',
    description: 'Django ORM Models: User, Profile (OneToOne), Post, Comment, Like (UniqueTogether), and Follow relationships.',
    content: `from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.exceptions import ValidationError

class Profile(models.Model):
    """
    Profile Model: Extends Django's User model with avatar, bio,
    website, location, and verified creator status.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar = models.ImageField(upload_to='avatars/', default='avatars/default.png', blank=True)
    bio = models.TextField(max_length=500, blank=True)
    website = models.URLField(max_length=200, blank=True)
    location = models.CharField(max_length=100, blank=True)
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"@{self.user.username}'s Profile"

    @property
    def followers_count(self):
        return self.user.followers.count()

    @property
    def following_count(self):
        return self.user.following.count()

    @property
    def posts_count(self):
        return self.user.posts.count()


class Post(models.Model):
    """
    Post Model: Stores user uploaded media, captions, filters, and timestamps.
    """
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    image = models.ImageField(upload_to='posts/%Y/%m/%d/')
    caption = models.TextField(max_length=2200, blank=True)
    location = models.CharField(max_length=150, blank=True)
    filter_style = models.CharField(max_length=50, default='normal', blank=True)
    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Post #{self.id} by @{self.author.username}"

    @property
    def likes_count(self):
        return self.likes.count()

    @property
    def comments_count(self):
        return self.comments.count()


class Like(models.Model):
    """
    Like Model: Stores likes on posts.
    Enforces unique constraint so each user can only like a post once.
    """
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['post', 'user'], name='unique_post_user_like')
        ]

    def __str__(self):
        return f"@{self.user.username} liked Post #{self.post.id}"


class Comment(models.Model):
    """
    Comment Model: Stores user comments on posts.
    """
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"Comment by @{self.author.username} on Post #{self.post.id}"


class Follow(models.Model):
    """
    Follow Model: Stores follower and following relationships.
    Prevents self-following and duplicate follows via validation & unique constraints.
    """
    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='following')
    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='followers')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['follower', 'following'], name='unique_follower_relationship')
        ]

    def clean(self):
        if self.follower == self.following:
            raise ValidationError("Users cannot follow themselves.")

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"@{self.follower.username} follows @{self.following.username}"`,
  },
  {
    path: 'core/views.py',
    name: 'views.py',
    category: 'views',
    description: 'Controller Views: Feed filtering, User registration/login, AJAX Likes, Comments, and Follow toggles.',
    content: `from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse, HttpResponseForbidden
from django.db.models import Q

from .models import Post, Profile, Comment, Like, Follow
from .forms import (
    UserRegisterForm,
    UserUpdateForm,
    ProfileUpdateForm,
    PostCreateForm,
    CommentForm
)

def register_view(request):
    """Register a new user account."""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, f"Welcome @{user.username}! Your account has been created.")
            login(request, user)
            return redirect('home')
    else:
        form = UserRegisterForm()

    return render(request, 'core/register.html', {'form': form, 'title': 'Register'})


def login_view(request):
    """Authenticate and log in an existing user."""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as @{username}.")
                next_url = request.GET.get('next', 'home')
                return redirect(next_url)
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()

    return render(request, 'core/login.html', {'form': form, 'title': 'Login'})


@login_required
def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('login')


@login_required
def home_view(request):
    """Feed view: Filter by 'all' or 'following'."""
    feed_filter = request.GET.get('feed', 'all')
    user = request.user

    if feed_filter == 'following':
        following_user_ids = user.following.values_list('following_id', flat=True)
        posts = Post.objects.filter(
            Q(author_id__in=following_user_ids) | Q(author=user)
        ).select_related('author', 'author__profile').prefetch_related('likes', 'comments')
    else:
        posts = Post.objects.all().select_related('author', 'author__profile').prefetch_related('likes', 'comments')

    already_following = user.following.values_list('following_id', flat=True)
    suggested_users = User.objects.exclude(id=user.id).exclude(id__in=already_following)[:5]

    return render(request, 'core/home.html', {
        'posts': posts,
        'suggested_users': suggested_users,
        'feed_filter': feed_filter,
    })


@login_required
def toggle_like_view(request, post_id):
    """Toggle Like/Unlike via AJAX or standard form POST."""
    post = get_object_or_404(Post, id=post_id)
    like_qs = Like.objects.filter(post=post, user=request.user)

    if like_qs.exists():
        like_qs.delete()
        liked = False
    else:
        Like.objects.create(post=post, user=request.user)
        liked = True

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'liked': liked, 'likes_count': post.likes_count})

    return redirect(request.META.get('HTTP_REFERER', 'home'))


@login_required
def toggle_follow_view(request, user_id):
    """Toggle Follow/Unfollow. Prevents self-following."""
    target_user = get_object_or_404(User, id=user_id)
    if target_user == request.user:
        messages.error(request, "You cannot follow yourself.")
        return redirect('profile', username=target_user.username)

    follow_qs = Follow.objects.filter(follower=request.user, following=target_user)
    if follow_qs.exists():
        follow_qs.delete()
        following = False
    else:
        Follow.objects.create(follower=request.user, following=target_user)
        following = True

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'following': following, 'followers_count': target_user.followers.count()})

    return redirect(request.META.get('HTTP_REFERER', 'home'))`,
  },
  {
    path: 'core/forms.py',
    name: 'forms.py',
    category: 'forms',
    description: 'Django Forms: Registration with email/username uniqueness, profile updates, photo post upload, and comments.',
    content: `from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile, Post, Comment

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True, label="Full Name")

    class Meta:
        model = User
        fields = ['username', 'first_name', 'email']

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("This email address is already in use.")
        return email


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['avatar', 'bio', 'website', 'location']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Write your bio...'}),
            'website': forms.URLInput(attrs={'placeholder': 'https://yourwebsite.com'}),
            'location': forms.TextInput(attrs={'placeholder': 'City, Country'}),
        }


class PostCreateForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['image', 'caption', 'location', 'filter_style']`,
  },
  {
    path: 'core/urls.py',
    name: 'urls.py',
    category: 'urls',
    description: 'URL Routing: Maps home, explore, profile, post CRUD, likes, comments, and follows to view functions.',
    content: `from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('explore/', views.explore_view, name='explore'),

    # Auth
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('password-change/', views.change_password_view, name='password_change'),

    # Profile
    path('profile/<str:username>/', views.profile_view, name='profile'),
    path('profile/edit/details/', views.edit_profile_view, name='edit_profile'),

    # Posts
    path('post/create/', views.create_post_view, name='create_post'),
    path('post/<int:post_id>/edit/', views.edit_post_view, name='edit_post'),
    path('post/<int:post_id>/delete/', views.delete_post_view, name='delete_post'),

    # Interactions
    path('post/<int:post_id>/like/', views.toggle_like_view, name='toggle_like'),
    path('post/<int:post_id>/comment/', views.add_comment_view, name='add_comment'),
    path('user/<int:user_id>/follow/', views.toggle_follow_view, name='toggle_follow'),
]`,
  },
  {
    path: 'mini_social/settings.py',
    name: 'settings.py',
    category: 'config',
    description: 'Django Project Configuration: SQLite database setup, Media files root, Authentication URLs, and Templates.',
    content: `import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'django-insecure-mini-social-platform-production-key'
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'core.apps.CoreConfig',
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'home'
LOGOUT_REDIRECT_URL = 'login'`,
  },
  {
    path: 'requirements.txt',
    name: 'requirements.txt',
    category: 'config',
    description: 'Python package dependencies: Django 5.x, Pillow for image processing, Crispy Forms, and dotenv.',
    content: `Django>=4.2,<5.2
Pillow>=10.0.0
django-crispy-forms>=2.1
crispy-bootstrap5>=2024.2
python-dotenv>=1.0.0`,
  },
  {
    path: 'core/migrations/0001_initial.py',
    name: '0001_initial.py',
    category: 'migrations',
    description: 'Initial database schema migration creating Profile, Post, Comment, Like, and Follow tables with constraints.',
    content: `# Generated by Django 5.0.0
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings

class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name='Profile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('avatar', models.ImageField(upload_to='avatars/')),
                ('bio', models.TextField(blank=True, max_length=500)),
                ('website', models.URLField(blank=True)),
                ('location', models.CharField(blank=True, max_length=100)),
                ('is_verified', models.BooleanField(default=False)),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL, on_delete=django.db.models.deletion.CASCADE)),
            ],
        ),
        migrations.CreateModel(
            name='Post',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('image', models.ImageField(upload_to='posts/%Y/%m/%d/')),
                ('caption', models.TextField(blank=True, max_length=2200)),
                ('location', models.CharField(blank=True, max_length=150)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('author', models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=django.db.models.deletion.CASCADE)),
            ],
        ),
    ]`,
  },
  {
    path: 'README.md',
    name: 'README.md',
    category: 'docs',
    description: 'Complete documentation: Architecture overview, installation, migration steps, and feature test scripts.',
    content: `# Mini Social Media Platform (Django + SQLite)

A beginner-friendly, production-ready Mini Social Media Platform inspired by Instagram.

## Quick Start Commands
1. python3 -m venv venv
2. source venv/bin/activate
3. pip install -r requirements.txt
4. python manage.py migrate
5. python manage.py createsuperuser
6. python manage.py runserver

Visit http://127.0.0.1:8000 in your browser!`,
  },
];

export const DjangoCodeHub: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(DJANGO_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'code' | 'schema' | 'guide'>('code');

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Title & Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 mb-8 border border-slate-700/60 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
              <Code2 className="w-3.5 h-3.5" />
              <span>Deliverable: Full Backend Architecture</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Python Django Backend & SQLite Suite
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Every single backend deliverable requested has been generated both here in this
              interactive explorer and directly on disk in <code className="text-emerald-400 font-mono">/django_project</code>.
            </p>
          </div>

          {/* Quick tab switcher */}
          <div className="flex bg-slate-800/80 p-1.5 rounded-2xl border border-slate-700 shrink-0">
            <button
              onClick={() => setActiveTab('code')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'code'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Source Files</span>
            </button>
            <button
              onClick={() => setActiveTab('schema')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'schema'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Schema Diagram</span>
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'guide'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Run Guide</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Tab Views */}
      {activeTab === 'code' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left File Tree */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs">
            <div className="text-xs font-bold text-slate-900 mb-3 flex items-center gap-2">
              <Folder className="w-4 h-4 text-emerald-600" />
              <span>Project Structure</span>
            </div>

            <div className="space-y-1">
              {DJANGO_FILES.map((file) => {
                const isSelected = selectedFile.path === file.path;
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-emerald-50 text-emerald-800 font-bold border border-emerald-200'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span className="truncate">{file.name}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 shrink-0 ml-1 uppercase">
                      {file.category}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-6 p-3 bg-slate-50 rounded-xl border border-slate-200/60 text-[11px] text-slate-600 space-y-1">
              <p className="font-bold text-slate-800">Files on Disk:</p>
              <p className="text-slate-500 font-mono text-[10px]">
                django_project/
                <br />├── manage.py
                <br />├── requirements.txt
                <br />├── core/
                <br />└── templates/
              </p>
            </div>
          </div>

          {/* Right Code Viewer */}
          <div className="lg:col-span-3 bg-slate-950 text-slate-200 rounded-2xl overflow-hidden border border-slate-800 shadow-xl flex flex-col">
            {/* Code Bar Header */}
            <div className="px-5 py-3.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  {selectedFile.path}
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {selectedFile.description}
                </p>
              </div>

              <button
                onClick={handleCopy}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700 shadow-xs"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Body */}
            <div className="p-5 font-mono text-xs overflow-x-auto leading-relaxed max-h-[550px] overflow-y-auto no-scrollbar selection:bg-emerald-500 selection:text-slate-950">
              <pre className="text-slate-300">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Schema Diagram */}
      {activeTab === 'schema' && (
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs">
          <h3 className="text-base font-extrabold text-slate-900 mb-2">
            Relational Database Schema & Foreign Keys
          </h3>
          <p className="text-xs text-slate-500 mb-6 max-w-2xl">
            Clean relational architecture built in Django with SQLite. Foreign keys cascade appropriately
            and constraints prevent duplicate likes or self-follow loops.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* User & Profile Card */}
            <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-slate-900 font-mono">User & Profile</span>
                <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-bold">1 : 1</span>
              </div>
              <ul className="text-xs text-slate-600 space-y-1 font-mono">
                <li>• id (PrimaryKey)</li>
                <li>• username (CharField, unique)</li>
                <li>• email (EmailField, unique)</li>
                <li>• password (hashed)</li>
                <li className="pt-2 text-slate-900 font-semibold">• Profile.avatar (ImageField)</li>
                <li>• Profile.bio (TextField)</li>
                <li>• Profile.website (URLField)</li>
                <li>• Profile.location (CharField)</li>
              </ul>
            </div>

            {/* Post Card */}
            <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-slate-900 font-mono">Post</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold">1 : N (User)</span>
              </div>
              <ul className="text-xs text-slate-600 space-y-1 font-mono">
                <li>• id (PrimaryKey)</li>
                <li>• author_id (ForeignKey User)</li>
                <li>• image (ImageField)</li>
                <li>• caption (TextField)</li>
                <li>• location (CharField)</li>
                <li>• filter_style (CharField)</li>
                <li>• created_at (DateTimeField)</li>
              </ul>
            </div>

            {/* Interactions Card */}
            <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-slate-900 font-mono">Like, Comment, Follow</span>
                <span className="text-[10px] bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-bold">Relations</span>
              </div>
              <ul className="text-xs text-slate-600 space-y-1 font-mono">
                <li className="font-semibold text-slate-900">Like:</li>
                <li>• post_id (FK Post)</li>
                <li>• user_id (FK User)</li>
                <li className="text-[10px] text-rose-600">UniqueConstraint(post, user)</li>
                <li className="font-semibold text-slate-900 pt-2">Comment:</li>
                <li>• post_id (FK Post)</li>
                <li>• author_id (FK User)</li>
                <li>• text (TextField)</li>
                <li className="font-semibold text-slate-900 pt-2">Follow:</li>
                <li>• follower_id (FK User)</li>
                <li>• following_id (FK User)</li>
                <li className="text-[10px] text-rose-600">Clean: follower != following</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Step-by-Step Setup Guide */}
      {activeTab === 'guide' && (
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs space-y-6">
          <div>
            <h3 className="text-base font-extrabold text-slate-900 mb-1">
              Step-by-Step Instructions to Run the Django Application
            </h3>
            <p className="text-xs text-slate-500">
              Follow these commands in your local machine's terminal to start the Django development server:
            </p>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl font-mono text-xs">
              <div className="flex items-center justify-between text-slate-400 text-[11px] mb-2 border-b border-slate-800 pb-2">
                <span>1. Setup Virtual Environment</span>
                <span className="text-emerald-400 font-bold">Terminal</span>
              </div>
              <code>
                cd django_project<br />
                python3 -m venv venv<br />
                source venv/bin/activate  # On Windows: venv\Scripts\activate
              </code>
            </div>

            <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl font-mono text-xs">
              <div className="flex items-center justify-between text-slate-400 text-[11px] mb-2 border-b border-slate-800 pb-2">
                <span>2. Install Dependencies</span>
                <span className="text-emerald-400 font-bold">Terminal</span>
              </div>
              <code>
                pip install -r requirements.txt
              </code>
            </div>

            <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl font-mono text-xs">
              <div className="flex items-center justify-between text-slate-400 text-[11px] mb-2 border-b border-slate-800 pb-2">
                <span>3. Apply Migrations & Create Superuser</span>
                <span className="text-emerald-400 font-bold">Terminal</span>
              </div>
              <code>
                python manage.py makemigrations<br />
                python manage.py migrate<br />
                python manage.py createsuperuser
              </code>
            </div>

            <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl font-mono text-xs">
              <div className="flex items-center justify-between text-slate-400 text-[11px] mb-2 border-b border-slate-800 pb-2">
                <span>4. Launch Server</span>
                <span className="text-emerald-400 font-bold">Terminal</span>
              </div>
              <code>
                python manage.py runserver<br />
                # Open http://127.0.0.1:8000 in your browser
              </code>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
