import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  Search,
  Heart,
  MessageCircle,
  Users,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';

interface ExplorePageProps {
  onOpenDetail: (postId: string) => void;
}

export const ExplorePage: React.FC<ExplorePageProps> = ({ onOpenDetail }) => {
  const {
    posts,
    users,
    profiles,
    openUserProfile,
    getPostLikesCount,
    getPostComments,
    toggleFollow,
    isFollowing,
    currentUser,
  } = useSocial();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Posts' },
    { id: 'photography', label: '#photography' },
    { id: 'travel', label: '#travel' },
    { id: 'architecture', label: '#architecture' },
    { id: 'foodie', label: '#foodie' },
    { id: 'design', label: '#design' },
    { id: 'minimalism', label: '#minimalism' },
  ];

  // Filter posts
  const filteredPosts = posts.filter((post) => {
    const author = users.find((u) => u.id === post.authorId);
    const authorUsername = author?.username.toLowerCase() || '';
    const captionLower = post.caption.toLowerCase();
    const locationLower = (post.location || '').toLowerCase();
    const query = searchQuery.trim().toLowerCase();

    // Search query match
    if (query) {
      const matchQuery =
        authorUsername.includes(query) ||
        captionLower.includes(query) ||
        locationLower.includes(query);
      if (!matchQuery) return false;
    }

    // Category match
    if (selectedCategory !== 'all') {
      return captionLower.includes(`#${selectedCategory}`);
    }

    return true;
  });

  // Matched users if searching
  const matchedUsers = searchQuery.trim()
    ? users.filter(
        (u) =>
          u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.fullName.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Search Header */}
      <div className="max-w-xl mx-auto mb-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search creators, hashtags, locations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white text-xs sm:text-sm text-slate-800 placeholder-slate-400 rounded-2xl border border-slate-200/90 shadow-[0_2px_4px_rgba(0,0,0,0.02)] focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 p-1"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Matched Users Section (if query active) */}
      {matchedUsers.length > 0 && (
        <div className="mb-6 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <h3 className="text-xs font-bold text-slate-900 mb-3 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-slate-500" />
            Creators matching "{searchQuery}"
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {matchedUsers.map((user) => {
              const prof = profiles.find((p) => p.userId === user.id);
              const following = isFollowing(user.id);
              return (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 hover:border-slate-200 transition-colors"
                >
                  <button
                    onClick={() => openUserProfile(user.id)}
                    className="flex items-center gap-2.5 text-left min-w-0"
                  >
                    <img
                      src={prof?.avatarUrl}
                      alt=""
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-full object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-slate-900 truncate">
                          @{user.username}
                        </span>
                        {prof?.isVerified && (
                          <CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0" />
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500 truncate block">
                        {user.fullName}
                      </span>
                    </div>
                  </button>

                  {currentUser && currentUser.id !== user.id && (
                    <button
                      onClick={() => toggleFollow(user.id)}
                      className={`px-2.5 py-1 text-[11px] font-semibold rounded-full shrink-0 transition-colors ${
                        following
                          ? 'bg-slate-100 text-slate-700'
                          : 'bg-rose-50 text-rose-600 hover:bg-rose-100'
                      }`}
                    >
                      {following ? 'Following' : 'Follow'}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Category Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 mb-6">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-1.5 text-xs font-semibold rounded-full whitespace-nowrap transition-all ${
              selectedCategory === cat.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Explore Grid */}
      {filteredPosts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-5">
          {filteredPosts.map((post) => {
            const author = users.find((u) => u.id === post.authorId);
            const likes = getPostLikesCount(post.id);
            const commentsCount = getPostComments(post.id).length;

            return (
              <div
                key={post.id}
                onClick={() => onOpenDetail(post.id)}
                className="group relative aspect-square bg-slate-950 rounded-xl overflow-hidden cursor-pointer shadow-xs"
              >
                <img
                  src={post.imageUrl}
                  alt={post.caption}
                  referrerPolicy="no-referrer"
                  className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-105 ${post.filter || 'filter-normal'}`}
                />

                {/* Dark Hover Overlay with Metrics */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3.5 text-white">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold truncate">@{author?.username}</span>
                  </div>

                  <div className="flex items-center justify-center gap-4 text-sm font-bold">
                    <div className="flex items-center gap-1.5">
                      <Heart className="w-4 h-4 fill-white" />
                      <span className="tabular-nums">{likes}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MessageCircle className="w-4 h-4 fill-white" />
                      <span className="tabular-nums">{commentsCount}</span>
                    </div>
                  </div>

                  {post.location ? (
                    <span className="text-[10px] text-white/80 truncate">
                      {post.location}
                    </span>
                  ) : (
                    <div></div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center">
          <p className="text-sm font-semibold text-slate-700 mb-1">
            No posts found for "{searchQuery || selectedCategory}"
          </p>
          <p className="text-xs text-slate-400">
            Try searching for another hashtag, user name, or clear your filters.
          </p>
        </div>
      )}
    </div>
  );
};
