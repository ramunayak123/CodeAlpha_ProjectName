import React from 'react';
import { useSocial } from '../context/SocialContext';
import { X, CheckCircle2 } from 'lucide-react';

interface FollowListModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  userId: string;
  type: 'followers' | 'following';
}

export const FollowListModal: React.FC<FollowListModalProps> = ({
  isOpen,
  onClose,
  title,
  userId,
  type,
}) => {
  const {
    getFollowers,
    getFollowing,
    currentUser,
    toggleFollow,
    isFollowing,
    openUserProfile,
  } = useSocial();

  if (!isOpen) return null;

  const usersList = type === 'followers' ? getFollowers(userId) : getFollowing(userId);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">{title}</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User rows */}
        <div className="p-4 overflow-y-auto space-y-3">
          {usersList.length > 0 ? (
            usersList.map((user) => {
              const following = isFollowing(user.id);
              const isSelf = currentUser?.id === user.id;

              return (
                <div
                  key={user.id}
                  className="flex items-center justify-between gap-3 p-1"
                >
                  <button
                    onClick={() => {
                      openUserProfile(user.id);
                      onClose();
                    }}
                    className="flex items-center gap-3 text-left min-w-0 group"
                  >
                    <img
                      src={user.profile?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=80&q=80'}
                      alt=""
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover shrink-0 border"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <p className="text-xs font-bold text-slate-900 group-hover:text-rose-600 truncate">
                          @{user.username}
                        </p>
                        {user.profile?.isVerified && (
                          <CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0" />
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate">
                        {user.fullName}
                      </p>
                    </div>
                  </button>

                  {!isSelf && currentUser && (
                    <button
                      onClick={() => toggleFollow(user.id)}
                      className={`px-3 py-1 text-xs font-semibold rounded-full shrink-0 transition-colors ${
                        following
                          ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          : 'bg-rose-600 text-white hover:bg-rose-700'
                      }`}
                    >
                      {following ? 'Following' : 'Follow'}
                    </button>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-xs text-slate-400">
              No users found in this list.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
