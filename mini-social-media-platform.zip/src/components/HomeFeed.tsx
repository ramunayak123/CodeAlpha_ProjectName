import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { StoriesBar } from './StoriesBar';
import { PostCard } from './PostCard';
import {
  Users,
  TrendingUp,
  Code2,
  CheckCircle2,
  UserPlus,
  UserCheck,
  Compass,
  Sparkles,
} from 'lucide-react';

interface HomeFeedProps {
  onOpenCreate: () => void;
  onOpenDetail: (postId: string) => void;
  onOpenAuth: () => void;
}

export const HomeFeed: React.FC<HomeFeedProps> = ({
  onOpenCreate,
  onOpenDetail,
  onOpenAuth,
}) => {
  const {
    posts,
    currentUser,
    users,
    profiles,
    follows,
    openUserProfile,
    toggleFollow,
    isFollowing,
    setCurrentView,
    getFollowers,
  } = useSocial();

  const [feedMode, setFeedMode] = useState<'all' | 'following'>('all');

  // Filter posts based on tab
  const displayedPosts = posts.filter((post) => {
    if (feedMode === 'all') return true;
    if (!currentUser) return true;
    // Show posts by people user follows OR own posts
    const isFollowed = isFollowing(post.authorId);
    const isOwn = post.authorId === currentUser.id;
    return isFollowed || isOwn;
  });

  // Suggested users to follow
  const suggestedUsers = users.filter((u) => {
    if (currentUser && u.id === currentUser.id) return false;
    return true;
  });

  const currentProfile = currentUser ? profiles.find((p) => p.userId === currentUser.id) : null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Feed Column (2 Cols on lg) */}
        <div className="lg:col-span-2 max-w-xl mx-auto w-full">
          {/* Stories bar */}
          <StoriesBar />

          {/* Feed Filter Segmented Control */}
          <div className="flex items-center justify-between mb-4 bg-white/80 backdrop-blur-xs p-1.5 rounded-xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setFeedMode('all')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  feedMode === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Discover All ({posts.length})
              </button>
              <button
                onClick={() => setFeedMode('following')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  feedMode === 'following'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Following Only
              </button>
            </div>

            <div className="text-[11px] text-slate-400 font-medium px-2 hidden sm:block">
              {displayedPosts.length} posts
            </div>
          </div>

          {/* Posts Stream */}
          {displayedPosts.length > 0 ? (
            <div className="space-y-6">
              {displayedPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onOpenDetail={onOpenDetail}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200/80 p-8 text-center shadow-xs">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                <Compass className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 mb-1">No Posts Found</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto mb-4">
                {feedMode === 'following'
                  ? 'You are not following any creators who have posted yet. Follow more users or view all posts!'
                  : 'Be the first creator to publish a new post!'}
              </p>
              <div className="flex justify-center gap-2">
                {feedMode === 'following' && (
                  <button
                    onClick={() => setFeedMode('all')}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                  >
                    View All Posts
                  </button>
                )}
                <button
                  onClick={onOpenCreate}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
                >
                  Create Post
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar Column (Desktop) */}
        <aside className="hidden lg:block space-y-5">
          {/* Current User Card */}
          {currentUser ? (
            <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
              <div className="flex items-center justify-between gap-3 mb-3">
                <button
                  onClick={() => openUserProfile(currentUser.id)}
                  className="flex items-center gap-3 text-left min-w-0 group"
                >
                  <img
                    src={currentProfile?.avatarUrl}
                    alt=""
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-slate-100 group-hover:ring-rose-200 transition-all shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 group-hover:text-rose-600 transition-colors truncate">
                      @{currentUser.username}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {currentUser.fullName}
                    </p>
                  </div>
                </button>

                <button
                  onClick={() => openUserProfile(currentUser.id)}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 transition-colors shrink-0"
                >
                  View Profile
                </button>
              </div>

              {/* Quick stats banner */}
              <div className="grid grid-cols-3 gap-2 py-2.5 px-3 bg-slate-50 rounded-xl text-center text-xs">
                <div>
                  <span className="block font-bold text-slate-900 tabular-nums">
                    {posts.filter((p) => p.authorId === currentUser.id).length}
                  </span>
                  <span className="text-[10px] text-slate-500">Posts</span>
                </div>
                <div>
                  <span className="block font-bold text-slate-900 tabular-nums">
                    {getFollowers(currentUser.id).length}
                  </span>
                  <span className="text-[10px] text-slate-500">Followers</span>
                </div>
                <div>
                  <span className="block font-bold text-slate-900 tabular-nums">
                    {follows.filter((f) => f.followerId === currentUser.id).length}
                  </span>
                  <span className="text-[10px] text-slate-500">Following</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200/80 p-4 text-center shadow-xs">
              <p className="text-xs text-slate-600 mb-3">
                Sign in to like, comment, and share photos with friends.
              </p>
              <button
                onClick={onOpenAuth}
                className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                Log In / Register
              </button>
            </div>
          )}

          {/* Suggested Creators */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                Suggested Creators
              </span>
              <button
                onClick={() => setCurrentView('explore')}
                className="text-[11px] font-semibold text-slate-500 hover:text-slate-800"
              >
                See All
              </button>
            </div>

            <div className="space-y-3">
              {suggestedUsers.slice(0, 4).map((user) => {
                const prof = profiles.find((p) => p.userId === user.id);
                const following = isFollowing(user.id);
                const userFollowers = getFollowers(user.id).length;

                return (
                  <div
                    key={user.id}
                    className="flex items-center justify-between gap-2.5"
                  >
                    <button
                      onClick={() => openUserProfile(user.id)}
                      className="flex items-center gap-2.5 min-w-0 text-left group"
                    >
                      <img
                        src={prof?.avatarUrl}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-slate-200 group-hover:ring-rose-300 transition-all"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <p className="text-xs font-bold text-slate-900 group-hover:text-rose-600 truncate">
                            {user.username}
                          </p>
                          {prof?.isVerified && (
                            <CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">
                          {userFollowers} followers
                        </p>
                      </div>
                    </button>

                    {currentUser && currentUser.id !== user.id && (
                      <button
                        onClick={() => toggleFollow(user.id)}
                        className={`px-3 py-1 text-[11px] font-semibold rounded-full transition-all shrink-0 ${
                          following
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                            : 'bg-rose-50 hover:bg-rose-100 text-rose-600'
                        }`}
                      >
                        {following ? 'Following' : 'Follow'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Django Backend Architecture Callout */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-2">
              <Code2 className="w-4 h-4" />
              <span>Full Python Django Architecture</span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              Explore the complete Django models, views, forms, migrations, and setup commands.
            </p>
            <button
              onClick={() => setCurrentView('django-code')}
              className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Inspect Django Source Code</span>
              <Sparkles className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Trending Topics */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-3">
              <TrendingUp className="w-3.5 h-3.5 text-slate-400" />
              Trending Tags
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[
                '#photography',
                '#minimalism',
                '#architecture',
                '#foodie',
                '#wanderlust',
                '#workspace',
              ].map((tag) => (
                <button
                  key={tag}
                  onClick={() => setCurrentView('explore')}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium rounded-lg transition-colors"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          <div className="text-[11px] text-slate-400 px-2 space-y-1">
            <p>© 2026 Mini Social Media Platform</p>
            <p>Django 5.0 + SQLite Backend · HTML5 / Tailwind Frontend</p>
          </div>
        </aside>

      </div>
    </div>
  );
};
