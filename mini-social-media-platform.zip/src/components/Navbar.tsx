import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  Compass,
  PlusSquare,
  Heart,
  User,
  Settings,
  LogOut,
  Code2,
  Users,
  Search,
  CheckCircle2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  onOpenCreate: () => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCreate, onOpenAuth }) => {
  const {
    currentUser,
    users,
    profiles,
    currentView,
    setCurrentView,
    openUserProfile,
    switchUser,
    logout,
    resetToDemoData,
  } = useSocial();

  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showSwitchModal, setShowSwitchModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const currentProfile = currentUser ? profiles.find((p) => p.userId === currentUser.id) : null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentView('explore');
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-[0_1px_3px_rgba(0,0,0,0.03)]">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setCurrentView('home')}
              className="flex items-center gap-2.5 text-left group transition-transform active:scale-95"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white shadow-sm shadow-rose-500/20 group-hover:shadow-md transition-shadow">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-slate-900 via-rose-900 to-slate-900 bg-clip-text text-transparent">
                  MiniSocial
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Search bar (Desktop) */}
          <div className="hidden md:flex flex-1 max-w-xs mx-4">
            <form onSubmit={handleSearchSubmit} className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search creators, #tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-100 hover:bg-slate-200/70 focus:bg-white text-xs text-slate-800 placeholder-slate-400 rounded-full border border-transparent focus:border-slate-300 focus:outline-none transition-all"
              />
            </form>
          </div>

          {/* Zone 3: Navigation Links & Actions */}
          <nav className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Feed Tab */}
            <button
              onClick={() => setCurrentView('home')}
              className={`p-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentView === 'home'
                  ? 'text-rose-600 bg-rose-50'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title="Home Feed"
            >
              <span className="text-xs font-semibold hidden lg:inline">Feed</span>
            </button>

            {/* Explore Tab */}
            <button
              onClick={() => setCurrentView('explore')}
              className={`p-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentView === 'explore'
                  ? 'text-rose-600 bg-rose-50'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title="Explore"
            >
              <Compass className="w-4 h-4" />
              <span className="text-xs font-semibold hidden lg:inline">Explore</span>
            </button>

            {/* Django Backend Hub Tab */}
            <button
              onClick={() => setCurrentView('django-code')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                currentView === 'django-code'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
              }`}
              title="Django Backend Code & Architecture"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Django Backend</span>
            </button>

            {/* Create Post Button */}
            {currentUser && (
              <button
                onClick={onOpenCreate}
                className="ml-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-full flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
                title="Create Post"
              >
                <PlusSquare className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Create</span>
              </button>
            )}

            {/* User Profile / Account Switcher Dropdown */}
            {currentUser ? (
              <div className="relative ml-1">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-slate-300 transition-all focus:outline-none"
                  title={`Logged in as @${currentUser.username}`}
                >
                  <img
                    src={currentProfile?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                    alt={currentUser.username}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200"
                  />
                </button>

                {showUserDropdown && (
                  <div
                    className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200/80 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                    onMouseLeave={() => setShowUserDropdown(false)}
                  >
                    <div className="px-4 py-2 border-b border-slate-100 flex items-center gap-3">
                      <img
                        src={currentProfile?.avatarUrl}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-slate-900 truncate">
                          {currentUser.fullName}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          @{currentUser.username}
                        </p>
                      </div>
                    </div>

                    <div className="py-1 text-xs">
                      <button
                        onClick={() => {
                          openUserProfile(currentUser.id);
                          setShowUserDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 font-medium"
                      >
                        <User className="w-4 h-4 text-slate-400" />
                        My Profile
                      </button>

                      <button
                        onClick={() => {
                          setCurrentView('edit-profile');
                          setShowUserDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 font-medium"
                      >
                        <Settings className="w-4 h-4 text-slate-400" />
                        Edit Profile & Password
                      </button>

                      <button
                        onClick={() => {
                          setShowSwitchModal(true);
                          setShowUserDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 font-medium text-rose-600"
                      >
                        <Users className="w-4 h-4" />
                        Switch Active Account
                      </button>

                      <div className="border-t border-slate-100 my-1"></div>

                      <button
                        onClick={() => {
                          resetToDemoData();
                          setShowUserDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-slate-500 hover:bg-slate-50 flex items-center gap-2.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                        Reset Demo Data
                      </button>

                      <button
                        onClick={() => {
                          logout();
                          setShowUserDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-red-600 hover:bg-red-50 flex items-center gap-2.5 font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        Log Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-full shadow-sm"
              >
                Sign In
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* Switch User Modal */}
      {showSwitchModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900">Switch Active Account</h3>
              <button
                onClick={() => setShowSwitchModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none p-1"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Select any pre-configured user profile to test multi-user follows, likes, and comments:
            </p>

            <div className="space-y-2 mb-4">
              {users.map((u) => {
                const prof = profiles.find((p) => p.userId === u.id);
                const isCurrent = u.id === currentUser?.id;
                return (
                  <button
                    key={u.id}
                    onClick={() => {
                      switchUser(u.id);
                      setShowSwitchModal(false);
                    }}
                    className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-left transition-all ${
                      isCurrent
                        ? 'border-rose-500 bg-rose-50/50 ring-1 ring-rose-500/30'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={prof?.avatarUrl}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 rounded-full object-cover border"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 truncate">{u.fullName}</p>
                        <p className="text-[11px] text-slate-500 truncate">@{u.username}</p>
                      </div>
                    </div>
                    {isCurrent && (
                      <CheckCircle2 className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                setShowSwitchModal(false);
                onOpenAuth();
              }}
              className="w-full py-2 border border-dashed border-slate-300 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              + Create or Log in with New Account
            </button>
          </div>
        </div>
      )}
    </>
  );
};
