import React, { useState } from 'react';
import { Post } from '../types';
import { useSocial } from '../context/SocialContext';
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  MoreHorizontal,
  MapPin,
  CheckCircle2,
  Trash2,
  Edit2,
  Send,
  UserPlus,
  UserCheck,
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  onOpenDetail?: (postId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onOpenDetail }) => {
  const {
    currentUser,
    getUserById,
    getProfileByUserId,
    hasLiked,
    toggleLike,
    getPostLikesCount,
    getPostComments,
    addComment,
    deleteComment,
    editPost,
    deletePost,
    openUserProfile,
    toggleSavePost,
    isSaved,
    toggleFollow,
    isFollowing,
  } = useSocial();

  const [commentText, setCommentText] = useState('');
  const [showHeartAnim, setShowHeartAnim] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedCaption, setEditedCaption] = useState(post.caption);
  const [copiedToast, setCopiedToast] = useState(false);

  const author = getUserById(post.authorId);
  const profile = getProfileByUserId(post.authorId);
  const isAuthor = currentUser?.id === post.authorId;
  const isUserLiked = hasLiked(post.id);
  const likesCount = getPostLikesCount(post.id);
  const comments = getPostComments(post.id);
  const saved = isSaved(post.id);
  const following = isFollowing(post.authorId);

  // Double tap to like
  const handleImageDoubleClick = () => {
    if (!isUserLiked) {
      toggleLike(post.id);
    }
    setShowHeartAnim(true);
    setTimeout(() => setShowHeartAnim(false), 800);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addComment(post.id, commentText);
    setCommentText('');
  };

  const handleSaveEdit = () => {
    editPost(post.id, editedCaption);
    setIsEditing(false);
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedToast(true);
    setShowMenu(false);
    setTimeout(() => setCopiedToast(false), 2000);
  };

  // Format relative timestamp
  const formatTimeAgo = (dateStr: string) => {
    const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  return (
    <article className="bg-white rounded-2xl border border-slate-200/80 mb-6 shadow-[0_1px_3px_rgba(0,0,0,0.03)] overflow-hidden transition-all">
      {/* Header */}
      <div className="p-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => author && openUserProfile(author.id)}
            className="relative group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-full p-[1.5px] bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 transition-transform group-hover:scale-105">
              <img
                src={profile?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
                alt={author?.username || 'User'}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover border-2 border-white"
              />
            </div>
          </button>

          <div className="text-left">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => author && openUserProfile(author.id)}
                className="text-xs font-bold text-slate-900 hover:text-rose-600 transition-colors"
              >
                {author?.username || 'unknown'}
              </button>
              {profile?.isVerified && (
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-50" />
              )}
              <span className="text-slate-400 text-xs">·</span>
              <span className="text-[11px] text-slate-400 font-medium">
                {formatTimeAgo(post.createdAt)}
              </span>
            </div>

            {post.location && (
              <div className="flex items-center gap-1 text-[11px] text-slate-500">
                <MapPin className="w-3 h-3 text-slate-400" />
                <span className="truncate max-w-[180px]">{post.location}</span>
              </div>
            )}
          </div>
        </div>

        {/* Actions Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            title="Post options"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {showMenu && (
            <div className="absolute right-0 mt-1 w-44 bg-white rounded-xl shadow-xl border border-slate-200/80 py-1.5 z-30 animate-in fade-in zoom-in-95 duration-150">
              {isAuthor ? (
                <>
                  <button
                    onClick={() => {
                      setIsEditing(true);
                      setShowMenu(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-slate-400" />
                    Edit Caption
                  </button>
                  <button
                    onClick={() => {
                      deletePost(post.id);
                      setShowMenu(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-medium text-red-600 hover:bg-red-50 flex items-center gap-2"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                    Delete Post
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      if (author) toggleFollow(author.id);
                      setShowMenu(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    {following ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                        Unfollow @{author?.username}
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5 text-rose-600" />
                        Follow @{author?.username}
                      </>
                    )}
                  </button>
                </>
              )}

              <div className="border-t border-slate-100 my-1"></div>

              <button
                onClick={handleCopyLink}
                className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
              >
                <Share2 className="w-3.5 h-3.5 text-slate-400" />
                Copy Link
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post Image Container */}
      <div
        className="relative bg-slate-950 aspect-square sm:aspect-[4/3] flex items-center justify-center overflow-hidden cursor-pointer select-none group"
        onDoubleClick={handleImageDoubleClick}
      >
        <img
          src={post.imageUrl}
          alt={post.caption || 'Post image'}
          referrerPolicy="no-referrer"
          className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.01] ${post.filter || 'filter-normal'}`}
        />

        {/* Double-tap Heart Pulse Animation */}
        {showHeartAnim && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
            <Heart className="w-24 h-24 text-white fill-white drop-shadow-2xl animate-heart-pulse" />
          </div>
        )}

        {/* Filter badge if custom */}
        {post.filter && post.filter !== 'filter-normal' && (
          <div className="absolute bottom-3 left-3 px-2 py-0.5 bg-black/50 backdrop-blur-md rounded-md text-[10px] font-semibold text-white/90">
            {post.filter.replace('filter-', '')}
          </div>
        )}
      </div>

      {/* Action Bar */}
      <div className="p-3.5 pb-2">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-3">
            {/* Heart Button */}
            <button
              onClick={() => toggleLike(post.id)}
              className="flex items-center gap-1.5 focus:outline-none transition-transform active:scale-125"
              title={isUserLiked ? 'Unlike' : 'Like'}
            >
              <Heart
                className={`w-6 h-6 transition-colors ${
                  isUserLiked
                    ? 'text-rose-600 fill-rose-600'
                    : 'text-slate-800 hover:text-slate-600'
                }`}
              />
            </button>

            {/* Comment Button */}
            <button
              onClick={() => onOpenDetail && onOpenDetail(post.id)}
              className="text-slate-800 hover:text-slate-600 transition-colors focus:outline-none"
              title="Comment"
            >
              <MessageCircle className="w-6 h-6" />
            </button>

            {/* Share Button */}
            <button
              onClick={handleCopyLink}
              className="text-slate-800 hover:text-slate-600 transition-colors focus:outline-none"
              title="Share post"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>

          {/* Bookmark Button */}
          <button
            onClick={() => toggleSavePost(post.id)}
            className="text-slate-800 hover:text-slate-600 transition-colors focus:outline-none"
            title={saved ? 'Remove Bookmark' : 'Save Post'}
          >
            <Bookmark
              className={`w-5 h-5 ${saved ? 'text-slate-900 fill-slate-900' : ''}`}
            />
          </button>
        </div>

        {/* Likes Count */}
        <div className="mb-2">
          <span className="text-xs font-bold text-slate-900 tabular-nums">
            {likesCount === 0
              ? 'Be the first to like this'
              : `${likesCount.toLocaleString()} ${likesCount === 1 ? 'like' : 'likes'}`}
          </span>
        </div>

        {/* Caption */}
        {isEditing ? (
          <div className="mb-3 space-y-2">
            <textarea
              value={editedCaption}
              onChange={(e) => setEditedCaption(e.target.value)}
              className="w-full text-xs p-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500"
              rows={3}
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setIsEditing(false)}
                className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-100 rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="px-3 py-1 text-xs bg-slate-900 text-white rounded-md font-semibold"
              >
                Save
              </button>
            </div>
          </div>
        ) : (
          post.caption && (
            <div className="text-xs text-slate-800 mb-2 leading-relaxed">
              <span className="font-bold text-slate-900 mr-1.5">
                {author?.username}
              </span>
              <span>{post.caption}</span>
            </div>
          )
        )}

        {/* Comments Count / View Details */}
        {comments.length > 0 && (
          <div className="space-y-1 mb-2">
            {comments.length > 2 && (
              <button
                onClick={() => onOpenDetail && onOpenDetail(post.id)}
                className="text-xs text-slate-400 hover:text-slate-600 font-medium block"
              >
                View all {comments.length} comments
              </button>
            )}

            {/* Preview latest 2 comments */}
            {comments.slice(-2).map((c) => (
              <div
                key={c.id}
                className="flex items-start justify-between text-xs text-slate-800 group/comment"
              >
                <div className="leading-snug">
                  <span className="font-bold text-slate-900 mr-1.5">
                    {c.author?.username || 'user'}
                  </span>
                  <span className="text-slate-700">{c.text}</span>
                </div>
                {(c.authorId === currentUser?.id || isAuthor) && (
                  <button
                    onClick={() => deleteComment(c.id)}
                    className="opacity-0 group-hover/comment:opacity-100 text-slate-400 hover:text-red-500 transition-opacity p-0.5 ml-2"
                    title="Delete comment"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {copiedToast && (
          <div className="text-[11px] text-emerald-600 font-semibold mb-1">
            ✓ Post link copied to clipboard!
          </div>
        )}
      </div>

      {/* Inline Comment Form */}
      {currentUser && (
        <form
          onSubmit={handleCommentSubmit}
          className="px-3.5 py-2.5 border-t border-slate-100 flex items-center gap-2"
        >
          {/* Quick emoji helper */}
          <div className="hidden sm:flex items-center gap-1">
            {['❤️', '🔥', '👏', '😍'].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => setCommentText((prev) => prev + emoji)}
                className="text-xs hover:scale-125 transition-transform p-0.5"
              >
                {emoji}
              </button>
            ))}
          </div>

          <input
            type="text"
            placeholder="Add a comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="flex-1 text-xs text-slate-800 placeholder-slate-400 bg-transparent focus:outline-none"
          />

          <button
            type="submit"
            disabled={!commentText.trim()}
            className="text-xs font-bold text-rose-600 disabled:opacity-30 disabled:cursor-not-allowed hover:text-rose-700 transition-colors flex items-center gap-1"
          >
            <span>Post</span>
            <Send className="w-3 h-3" />
          </button>
        </form>
      )}
    </article>
  );
};
