import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  Trash2,
  Send,
  CheckCircle2,
  MapPin,
} from 'lucide-react';

interface PostDetailModalProps {
  postId: string | null;
  onClose: () => void;
}

export const PostDetailModal: React.FC<PostDetailModalProps> = ({
  postId,
  onClose,
}) => {
  const {
    posts,
    getUserById,
    getProfileByUserId,
    currentUser,
    hasLiked,
    toggleLike,
    getPostLikesCount,
    getPostComments,
    addComment,
    deleteComment,
    toggleSavePost,
    isSaved,
    openUserProfile,
  } = useSocial();

  const [commentText, setCommentText] = useState('');

  if (!postId) return null;

  const post = posts.find((p) => p.id === postId);
  if (!post) return null;

  const author = getUserById(post.authorId);
  const profile = getProfileByUserId(post.authorId);
  const comments = getPostComments(post.id);
  const likesCount = getPostLikesCount(post.id);
  const isUserLiked = hasLiked(post.id);
  const saved = isSaved(post.id);
  const isPostAuthor = currentUser?.id === post.authorId;

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addComment(post.id, commentText);
    setCommentText('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col md:flex-row max-h-[90vh]">
        {/* Left: Image */}
        <div className="md:w-3/5 bg-slate-950 flex items-center justify-center overflow-hidden relative">
          <img
            src={post.imageUrl}
            alt=""
            referrerPolicy="no-referrer"
            className={`w-full h-full max-h-[500px] md:max-h-none object-cover ${post.filter || 'filter-normal'}`}
          />
          {post.filter && post.filter !== 'filter-normal' && (
            <div className="absolute bottom-3 left-3 px-2 py-0.5 bg-black/50 backdrop-blur-md rounded text-[10px] font-semibold text-white">
              {post.filter.replace('filter-', '')}
            </div>
          )}
        </div>

        {/* Right: Comments & Actions */}
        <div className="md:w-2/5 flex flex-col justify-between h-[450px] md:h-auto bg-white">
          {/* Header */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => {
                  if (author) {
                    openUserProfile(author.id);
                    onClose();
                  }
                }}
                className="flex items-center gap-2 text-left"
              >
                <img
                  src={profile?.avatarUrl}
                  alt=""
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover border"
                />
                <div>
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-bold text-slate-900">
                      @{author?.username}
                    </span>
                    {profile?.isVerified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                    )}
                  </div>
                  {post.location && (
                    <span className="text-[10px] text-slate-400 block truncate max-w-[150px]">
                      {post.location}
                    </span>
                  )}
                </div>
              </button>
            </div>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Comments List */}
          <div className="p-4 overflow-y-auto flex-1 space-y-3.5 text-xs">
            {/* Caption as top comment */}
            {post.caption && (
              <div className="flex items-start gap-2.5 pb-2 border-b border-slate-100">
                <img
                  src={profile?.avatarUrl}
                  alt=""
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                />
                <div className="leading-relaxed">
                  <span className="font-bold text-slate-900 mr-1.5">
                    {author?.username}
                  </span>
                  <span className="text-slate-700">{post.caption}</span>
                </div>
              </div>
            )}

            {/* Comments */}
            {comments.map((c) => (
              <div
                key={c.id}
                className="flex items-start justify-between gap-2 group"
              >
                <div className="flex items-start gap-2.5">
                  <img
                    src={c.profile?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=60&q=80'}
                    alt=""
                    referrerPolicy="no-referrer"
                    className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                  />
                  <div>
                    <span className="font-bold text-slate-900 mr-1.5">
                      {c.author?.username || 'user'}
                    </span>
                    <span className="text-slate-700">{c.text}</span>
                  </div>
                </div>

                {(c.authorId === currentUser?.id || isPostAuthor) && (
                  <button
                    onClick={() => deleteComment(c.id)}
                    className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-opacity p-1 shrink-0"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}

            {comments.length === 0 && !post.caption && (
              <div className="text-center py-10 text-slate-400">
                No comments yet. Start the conversation!
              </div>
            )}
          </div>

          {/* Action Footer */}
          <div className="p-3.5 border-t border-slate-100 bg-white">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleLike(post.id)}
                  className="focus:outline-none"
                >
                  <Heart
                    className={`w-5 h-5 ${
                      isUserLiked
                        ? 'text-rose-600 fill-rose-600'
                        : 'text-slate-800 hover:text-slate-600'
                    }`}
                  />
                </button>
                <button
                  onClick={() => toggleSavePost(post.id)}
                  className="text-slate-800 hover:text-slate-600"
                >
                  <Bookmark
                    className={`w-5 h-5 ${saved ? 'text-slate-900 fill-slate-900' : ''}`}
                  />
                </button>
              </div>
              <span className="text-xs font-bold text-slate-900 tabular-nums">
                {likesCount} {likesCount === 1 ? 'like' : 'likes'}
              </span>
            </div>

            {/* Add Comment input */}
            {currentUser && (
              <form onSubmit={handleCommentSubmit} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add a comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1 text-xs border border-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-rose-500"
                />
                <button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold disabled:opacity-40"
                >
                  Post
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
