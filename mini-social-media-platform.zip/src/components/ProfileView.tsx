import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { PostCard } from './PostCard';
import {
  Grid,
  Bookmark,
  MapPin,
  ExternalLink,
  CheckCircle2,
  Settings,
  UserPlus,
  UserCheck,
  Heart,
  MessageCircle,
  Camera,
  Layers,
} from 'lucide-react';

interface ProfileViewProps {
  userId: string;
  onOpenDetail: (postId: string) => void;
  onOpenEditProfile: () => void;
  onOpenFollowers: (userId: string) => void;
  onOpenFollowing: (userId: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userId,
  onOpenDetail,
  onOpenEditProfile,
  onOpenFollowers,
  onOpenFollowing,
}) => {
  const {
    currentUser,
    getUserById,
    getProfileByUserId,
    getUserPosts,
    toggleFollow,
    isFollowing,
    getFollowers,
    getFollowing,
    posts,
    savedPostIds,
    getPostLikesCount,
    getPostComments,
  } = useSocial();

  const [activeTab, setActiveTab] = useState<'grid' | 'feed' | 'saved'>('grid');

  const user = getUserById(userId);
  const profile = getProfileByUserId(userId);
  const isOwnProfile = currentUser?.id === userId;
  const userPosts = getUserPosts(userId);
  const followers = getFollowers(userId);
  const following = getFollowing(userId);
  const userIsFollowed = isFollowing(userId);

  // Saved posts (only applicable for own profile)
  const savedPosts = posts.filter((p) => savedPostIds.includes(p.id));

  if (!user || !profile) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <p className="text-sm text-slate-500">User not found.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Profile Header */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 mb-8 shadow-[0_1px_3px_rgba(0,0,0,0.02)]">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-10">
          
          {/* Avatar with Story gradient border */}
          <div className="relative group shrink-0">
            <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full p-1 bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 shadow-md">
              <img
                src={profile.avatarUrl}
                alt={user.username}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover border-4 border-white bg-slate-100"
              />
            </div>
          </div>

          {/* User Details & Stats */}
          <div className="flex-1 text-center sm:text-left min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
              <div className="flex items-center justify-center sm:justify-start gap-1.5">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  @{user.username}
                </h1>
                {profile.isVerified && (
                  <span title="Verified Creator">
                    <CheckCircle2 className="w-5 h-5 text-blue-500 fill-blue-50 shrink-0" />
                  </span>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-center gap-2">
                {isOwnProfile ? (
                  <button
                    onClick={onOpenEditProfile}
                    className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>Edit Profile</span>
                  </button>
                ) : (
                  currentUser && (
                    <button
                      onClick={() => toggleFollow(user.id)}
                      className={`px-5 py-1.5 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 ${
                        userIsFollowed
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                          : 'bg-rose-600 hover:bg-rose-700 text-white'
                      }`}
                    >
                      {userIsFollowed ? (
                        <>
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Follow</span>
                        </>
                      )}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Metrics Row */}
            <div className="flex items-center justify-center sm:justify-start gap-6 sm:gap-8 mb-4 text-xs">
              <div className="text-center sm:text-left">
                <span className="font-extrabold text-slate-900 text-sm block sm:inline mr-1 tabular-nums">
                  {userPosts.length}
                </span>
                <span className="text-slate-500 font-medium">posts</span>
              </div>

              <button
                onClick={() => onOpenFollowers(user.id)}
                className="text-center sm:text-left hover:text-rose-600 transition-colors focus:outline-none"
              >
                <span className="font-extrabold text-slate-900 text-sm block sm:inline mr-1 tabular-nums">
                  {followers.length}
                </span>
                <span className="text-slate-500 font-medium">followers</span>
              </button>

              <button
                onClick={() => onOpenFollowing(user.id)}
                className="text-center sm:text-left hover:text-rose-600 transition-colors focus:outline-none"
              >
                <span className="font-extrabold text-slate-900 text-sm block sm:inline mr-1 tabular-nums">
                  {following.length}
                </span>
                <span className="text-slate-500 font-medium">following</span>
              </button>
            </div>

            {/* Bio & Links */}
            <div className="space-y-1.5 text-xs text-slate-700 max-w-lg">
              <p className="font-bold text-slate-900 text-sm">{user.fullName}</p>
              {profile.bio && (
                <p className="whitespace-pre-line leading-relaxed text-slate-600">
                  {profile.bio}
                </p>
              )}
              {profile.location && (
                <div className="flex items-center justify-center sm:justify-start gap-1 text-slate-500">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{profile.location}</span>
                </div>
              )}
              {profile.website && (
                <div className="flex items-center justify-center sm:justify-start gap-1">
                  <ExternalLink className="w-3.5 h-3.5 text-rose-500" />
                  <a
                    href={profile.website}
                    target="_blank"
                    rel="noreferrer"
                    className="text-rose-600 hover:underline font-medium"
                  >
                    {profile.website.replace('https://', '')}
                  </a>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="flex items-center justify-center gap-8 border-b border-slate-200 mb-6">
        <button
          onClick={() => setActiveTab('grid')}
          className={`pb-3 text-xs font-bold flex items-center gap-1.5 uppercase tracking-wider transition-colors border-b-2 -mb-[1px] ${
            activeTab === 'grid'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-700'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span>Grid</span>
        </button>

        <button
          onClick={() => setActiveTab('feed')}
          className={`pb-3 text-xs font-bold flex items-center gap-1.5 uppercase tracking-wider transition-colors border-b-2 -mb-[1px] ${
            activeTab === 'feed'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Feed</span>
        </button>

        {isOwnProfile && (
          <button
            onClick={() => setActiveTab('saved')}
            className={`pb-3 text-xs font-bold flex items-center gap-1.5 uppercase tracking-wider transition-colors border-b-2 -mb-[1px] ${
              activeTab === 'saved'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved ({savedPosts.length})</span>
          </button>
        )}
      </div>

      {/* Tab Content */}
      {activeTab === 'grid' && (
        userPosts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-5">
            {userPosts.map((post) => {
              const likes = getPostLikesCount(post.id);
              const commentsCount = getPostComments(post.id).length;

              return (
                <div
                  key={post.id}
                  onClick={() => onOpenDetail(post.id)}
                  className="group relative aspect-square bg-slate-950 rounded-2xl overflow-hidden cursor-pointer shadow-xs"
                >
                  <img
                    src={post.imageUrl}
                    alt=""
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-105 ${post.filter || 'filter-normal'}`}
                  />
                  {/* Hover stats */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-5 text-white text-sm font-bold">
                    <div className="flex items-center gap-1.5">
                      <Heart className="w-4 h-4 fill-white" />
                      <span className="tabular-nums">{likes}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MessageCircle className="w-4 h-4 fill-white" />
                      <span className="tabular-nums">{commentsCount}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center">
            <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Camera className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 mb-1">No Posts Yet</h4>
            <p className="text-xs text-slate-500">When you share photos, they will appear on your profile.</p>
          </div>
        )
      )}

      {activeTab === 'feed' && (
        <div className="max-w-xl mx-auto space-y-6">
          {userPosts.map((post) => (
            <PostCard key={post.id} post={post} onOpenDetail={onOpenDetail} />
          ))}
        </div>
      )}

      {activeTab === 'saved' && (
        savedPosts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-5">
            {savedPosts.map((post) => {
              const likes = getPostLikesCount(post.id);
              const commentsCount = getPostComments(post.id).length;
              return (
                <div
                  key={post.id}
                  onClick={() => onOpenDetail(post.id)}
                  className="group relative aspect-square bg-slate-950 rounded-2xl overflow-hidden cursor-pointer shadow-xs"
                >
                  <img
                    src={post.imageUrl}
                    alt=""
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-105 ${post.filter || 'filter-normal'}`}
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-5 text-white text-sm font-bold">
                    <div className="flex items-center gap-1.5">
                      <Heart className="w-4 h-4 fill-white" />
                      <span className="tabular-nums">{likes}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MessageCircle className="w-4 h-4 fill-white" />
                      <span className="tabular-nums">{commentsCount}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center">
            <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Bookmark className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 mb-1">Save Photos</h4>
            <p className="text-xs text-slate-500">Save photos that you want to see again. No one is notified.</p>
          </div>
        )
      )}
    </div>
  );
};
