import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { Story } from '../types';
import { Plus, X } from 'lucide-react';

export const StoriesBar: React.FC = () => {
  const { stories, users, profiles, currentUser, openUserProfile } = useSocial();
  const [activeStory, setActiveStory] = useState<Story | null>(null);

  const currentProfile = currentUser ? profiles.find((p) => p.userId === currentUser.id) : null;

  return (
    <>
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 mb-5 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
        <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-1">
          {/* Your Story item */}
          <div className="flex flex-col items-center gap-1.5 shrink-0 cursor-pointer">
            <div className="relative">
              <div className="w-14 h-14 rounded-full p-0.5 border border-slate-200">
                <img
                  src={currentProfile?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
                  alt="Your story"
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="absolute bottom-0 right-0 w-4 h-4 bg-rose-500 rounded-full text-white flex items-center justify-center border-2 border-white shadow-xs">
                <Plus className="w-3 h-3 stroke-[3]" />
              </div>
            </div>
            <span className="text-[11px] font-medium text-slate-700 truncate max-w-[62px]">
              Your story
            </span>
          </div>

          {/* Other stories */}
          {stories.map((story) => {
            const author = users.find((u) => u.id === story.userId);
            const prof = profiles.find((p) => p.userId === story.userId);
            if (!author) return null;

            return (
              <button
                key={story.id}
                onClick={() => setActiveStory(story)}
                className="flex flex-col items-center gap-1.5 shrink-0 cursor-pointer group focus:outline-none"
              >
                <div className="w-14 h-14 rounded-full p-[2px] bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 transition-transform group-hover:scale-105 active:scale-95 shadow-xs">
                  <div className="w-full h-full rounded-full p-[2px] bg-white">
                    <img
                      src={prof?.avatarUrl}
                      alt={author.username}
                      referrerPolicy="no-referrer"
                      className="w-full h-full rounded-full object-cover"
                    />
                  </div>
                </div>
                <span className="text-[11px] font-medium text-slate-700 truncate max-w-[62px]">
                  {author.username}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Story Viewer Modal */}
      {activeStory && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-sm w-full bg-slate-950 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[520px]">
            {/* Story progress bar */}
            <div className="absolute top-3 left-3 right-3 z-20 flex gap-1">
              <div className="h-1 bg-white/40 flex-1 rounded-full overflow-hidden">
                <div className="h-full bg-white animate-[pulse_3s_ease-in-out_infinite]"></div>
              </div>
            </div>

            {/* Top author row */}
            <div className="absolute top-6 left-3 right-3 z-20 flex items-center justify-between text-white">
              {(() => {
                const author = users.find((u) => u.id === activeStory.userId);
                const prof = profiles.find((p) => p.userId === activeStory.userId);
                return (
                  <div className="flex items-center gap-2">
                    <img
                      src={prof?.avatarUrl}
                      alt=""
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded-full border border-white/40 object-cover"
                    />
                    <button
                      onClick={() => {
                        if (author) {
                          openUserProfile(author.id);
                          setActiveStory(null);
                        }
                      }}
                      className="text-xs font-bold text-white hover:underline"
                    >
                      @{author?.username}
                    </button>
                    <span className="text-[10px] text-white/70">· 2h ago</span>
                  </div>
                );
              })()}

              <button
                onClick={() => setActiveStory(null)}
                className="w-7 h-7 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Story Image */}
            <img
              src={activeStory.imageUrl}
              alt=""
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover flex-1"
            />

            {/* Caption */}
            {activeStory.caption && (
              <div className="absolute bottom-4 left-4 right-4 z-20 bg-black/60 backdrop-blur-md p-3 rounded-xl text-white text-xs">
                {activeStory.caption}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
