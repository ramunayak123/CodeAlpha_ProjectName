import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Profile, Post, Comment, Like, Follow, Story, PageView } from '../types';
import {
  INITIAL_USERS,
  INITIAL_PROFILES,
  INITIAL_POSTS,
  INITIAL_LIKES,
  INITIAL_COMMENTS,
  INITIAL_FOLLOWS,
  INITIAL_STORIES,
} from '../data/seedData';

interface SocialContextType {
  currentUser: User | null;
  users: User[];
  profiles: Profile[];
  posts: Post[];
  likes: Like[];
  comments: Comment[];
  follows: Follow[];
  stories: Story[];
  savedPostIds: string[];
  currentView: PageView;
  selectedProfileUserId: string | null;
  selectedPostId: string | null;
  
  // Navigation
  setCurrentView: (view: PageView) => void;
  openUserProfile: (userId: string) => void;
  setSelectedPostId: (id: string | null) => void;

  // Auth
  login: (usernameOrEmail: string, password?: string) => { success: boolean; error?: string };
  register: (data: { username: string; email: string; fullName: string; password?: string }) => { success: boolean; error?: string };
  logout: () => void;
  switchUser: (userId: string) => void;
  updateProfile: (data: Partial<Profile> & { fullName?: string }) => void;
  updatePassword: (currentPass: string, newPass: string) => { success: boolean; error?: string };

  // Posts
  createPost: (data: { imageUrl: string; filter?: string; caption: string; location?: string }) => Post;
  editPost: (postId: string, caption: string) => void;
  deletePost: (postId: string) => void;
  toggleSavePost: (postId: string) => void;
  isSaved: (postId: string) => boolean;

  // Likes
  toggleLike: (postId: string) => void;
  hasLiked: (postId: string, userId?: string) => boolean;
  getPostLikesCount: (postId: string) => number;

  // Comments
  getPostComments: (postId: string) => (Comment & { author?: User; profile?: Profile })[];
  addComment: (postId: string, text: string) => void;
  deleteComment: (commentId: string) => void;

  // Follows
  toggleFollow: (targetUserId: string) => void;
  isFollowing: (targetUserId: string, observerId?: string) => boolean;
  getFollowers: (userId: string) => (User & { profile?: Profile })[];
  getFollowing: (userId: string) => (User & { profile?: Profile })[];

  // Helpers
  getUserById: (userId: string) => User | undefined;
  getProfileByUserId: (userId: string) => Profile | undefined;
  getUserPosts: (userId: string) => Post[];
  resetToDemoData: () => void;
}

const SocialContext = createContext<SocialContextType | undefined>(undefined);

const STORAGE_KEY = 'mini_social_platform_v1';

export const SocialProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial from localStorage or defaults
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_users`);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [profiles, setProfiles] = useState<Profile[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_profiles`);
    return saved ? JSON.parse(saved) : INITIAL_PROFILES;
  });

  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_posts`);
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [likes, setLikes] = useState<Like[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_likes`);
    return saved ? JSON.parse(saved) : INITIAL_LIKES;
  });

  const [comments, setComments] = useState<Comment[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_comments`);
    return saved ? JSON.parse(saved) : INITIAL_COMMENTS;
  });

  const [follows, setFollows] = useState<Follow[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_follows`);
    return saved ? JSON.parse(saved) : INITIAL_FOLLOWS;
  });

  const [stories] = useState<Story[]>(INITIAL_STORIES);

  const [savedPostIds, setSavedPostIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_saved_posts`);
    return saved ? JSON.parse(saved) : ['post-2', 'post-4'];
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_current_user`);
    return saved || 'user-1';
  });

  const [currentView, setCurrentView] = useState<PageView>('home');
  const [selectedProfileUserId, setSelectedProfileUserId] = useState<string | null>(null);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_users`, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_profiles`, JSON.stringify(profiles));
  }, [profiles]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_posts`, JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_likes`, JSON.stringify(likes));
  }, [likes]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_comments`, JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_follows`, JSON.stringify(follows));
  }, [follows]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_saved_posts`, JSON.stringify(savedPostIds));
  }, [savedPostIds]);

  useEffect(() => {
    if (currentUserId) {
      localStorage.setItem(`${STORAGE_KEY}_current_user`, currentUserId);
    } else {
      localStorage.removeItem(`${STORAGE_KEY}_current_user`);
    }
  }, [currentUserId]);

  const currentUser = users.find((u) => u.id === currentUserId) || null;

  const getUserById = (userId: string) => users.find((u) => u.id === userId);
  const getProfileByUserId = (userId: string) => profiles.find((p) => p.userId === userId);
  const getUserPosts = (userId: string) =>
    posts
      .filter((p) => p.authorId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const openUserProfile = (userId: string) => {
    setSelectedProfileUserId(userId);
    setCurrentView('profile');
  };

  // Auth actions
  const login = (usernameOrEmail: string, _password?: string) => {
    const clean = usernameOrEmail.trim().toLowerCase();
    const user = users.find(
      (u) => u.username.toLowerCase() === clean || u.email.toLowerCase() === clean
    );
    if (!user) {
      return { success: false, error: 'No account found with this username or email.' };
    }
    setCurrentUserId(user.id);
    setCurrentView('home');
    return { success: true };
  };

  const register = ({
    username,
    email,
    fullName,
  }: {
    username: string;
    email: string;
    fullName: string;
    password?: string;
  }) => {
    const cleanUsername = username.trim().toLowerCase();
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanUsername || cleanUsername.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters.' };
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (users.some((u) => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, error: 'Username is already taken. Please choose another.' };
    }
    if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'An account with this email already exists.' };
    }

    const newId = `user-${Date.now()}`;
    const newUser: User = {
      id: newId,
      username: cleanUsername,
      email: cleanEmail,
      fullName: fullName.trim() || cleanUsername,
      dateJoined: new Date().toISOString(),
    };

    const newProfile: Profile = {
      id: `prof-${Date.now()}`,
      userId: newId,
      avatarUrl: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80`,
      bio: 'New member of the Mini Social Media Platform! ✨',
      location: 'Earth',
      isVerified: false,
    };

    setUsers((prev) => [...prev, newUser]);
    setProfiles((prev) => [...prev, newProfile]);
    setCurrentUserId(newId);
    setCurrentView('home');
    return { success: true };
  };

  const logout = () => {
    setCurrentUserId('');
    setCurrentView('auth');
  };

  const switchUser = (userId: string) => {
    if (users.some((u) => u.id === userId)) {
      setCurrentUserId(userId);
    }
  };

  const updateProfile = (data: Partial<Profile> & { fullName?: string }) => {
    if (!currentUser) return;

    if (data.fullName !== undefined) {
      setUsers((prev) =>
        prev.map((u) => (u.id === currentUser.id ? { ...u, fullName: data.fullName! } : u))
      );
    }

    setProfiles((prev) =>
      prev.map((p) => {
        if (p.userId === currentUser.id) {
          return {
            ...p,
            avatarUrl: data.avatarUrl ?? p.avatarUrl,
            bio: data.bio ?? p.bio,
            website: data.website ?? p.website,
            location: data.location ?? p.location,
          };
        }
        return p;
      })
    );
  };

  const updatePassword = (_currentPass: string, newPass: string) => {
    if (!newPass || newPass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }
    return { success: true };
  };

  // Posts
  const createPost = ({
    imageUrl,
    filter,
    caption,
    location,
  }: {
    imageUrl: string;
    filter?: string;
    caption: string;
    location?: string;
  }): Post => {
    const newPost: Post = {
      id: `post-${Date.now()}`,
      authorId: currentUser?.id || 'user-1',
      imageUrl,
      filter: filter || 'filter-normal',
      caption,
      location,
      createdAt: new Date().toISOString(),
    };
    setPosts((prev) => [newPost, ...prev]);
    setCurrentView('home');
    return newPost;
  };

  const editPost = (postId: string, caption: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, caption, updatedAt: new Date().toISOString() } : p))
    );
  };

  const deletePost = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    setLikes((prev) => prev.filter((l) => l.postId !== postId));
    setComments((prev) => prev.filter((c) => c.postId !== postId));
    setSavedPostIds((prev) => prev.filter((id) => id !== postId));
    if (selectedPostId === postId) {
      setSelectedPostId(null);
    }
  };

  const toggleSavePost = (postId: string) => {
    setSavedPostIds((prev) =>
      prev.includes(postId) ? prev.filter((id) => id !== postId) : [...prev, postId]
    );
  };

  const isSaved = (postId: string) => savedPostIds.includes(postId);

  // Likes
  const toggleLike = (postId: string) => {
    if (!currentUser) return;
    setLikes((prev) => {
      const existing = prev.find((l) => l.postId === postId && l.userId === currentUser.id);
      if (existing) {
        return prev.filter((l) => l.id !== existing.id);
      } else {
        return [
          ...prev,
          {
            id: `like-${Date.now()}-${Math.random()}`,
            postId,
            userId: currentUser.id,
            createdAt: new Date().toISOString(),
          },
        ];
      }
    });
  };

  const hasLiked = (postId: string, userId?: string) => {
    const targetUserId = userId || currentUser?.id;
    if (!targetUserId) return false;
    return likes.some((l) => l.postId === postId && l.userId === targetUserId);
  };

  const getPostLikesCount = (postId: string) => likes.filter((l) => l.postId === postId).length;

  // Comments
  const getPostComments = (postId: string) => {
    return comments
      .filter((c) => c.postId === postId)
      .map((c) => ({
        ...c,
        author: users.find((u) => u.id === c.authorId),
        profile: profiles.find((p) => p.userId === c.authorId),
      }))
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  };

  const addComment = (postId: string, text: string) => {
    if (!currentUser || !text.trim()) return;
    const newComment: Comment = {
      id: `comm-${Date.now()}`,
      postId,
      authorId: currentUser.id,
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };
    setComments((prev) => [...prev, newComment]);
  };

  const deleteComment = (commentId: string) => {
    setComments((prev) => prev.filter((c) => c.id !== commentId));
  };

  // Follows
  const toggleFollow = (targetUserId: string) => {
    if (!currentUser || targetUserId === currentUser.id) return;
    setFollows((prev) => {
      const existing = prev.find(
        (f) => f.followerId === currentUser.id && f.followingId === targetUserId
      );
      if (existing) {
        return prev.filter((f) => f.id !== existing.id);
      } else {
        return [
          ...prev,
          {
            id: `f-${Date.now()}`,
            followerId: currentUser.id,
            followingId: targetUserId,
            createdAt: new Date().toISOString(),
          },
        ];
      }
    });
  };

  const isFollowing = (targetUserId: string, observerId?: string) => {
    const observer = observerId || currentUser?.id;
    if (!observer || targetUserId === observer) return false;
    return follows.some((f) => f.followerId === observer && f.followingId === targetUserId);
  };

  const getFollowers = (userId: string) => {
    const followerIds = follows.filter((f) => f.followingId === userId).map((f) => f.followerId);
    return users
      .filter((u) => followerIds.includes(u.id))
      .map((u) => ({ ...u, profile: getProfileByUserId(u.id) }));
  };

  const getFollowing = (userId: string) => {
    const followingIds = follows.filter((f) => f.followerId === userId).map((f) => f.followingId);
    return users
      .filter((u) => followingIds.includes(u.id))
      .map((u) => ({ ...u, profile: getProfileByUserId(u.id) }));
  };

  const resetToDemoData = () => {
    setUsers(INITIAL_USERS);
    setProfiles(INITIAL_PROFILES);
    setPosts(INITIAL_POSTS);
    setLikes(INITIAL_LIKES);
    setComments(INITIAL_COMMENTS);
    setFollows(INITIAL_FOLLOWS);
    setSavedPostIds(['post-2', 'post-4']);
    setCurrentUserId('user-1');
    setCurrentView('home');
    localStorage.clear();
  };

  return (
    <SocialContext.Provider
      value={{
        currentUser,
        users,
        profiles,
        posts,
        likes,
        comments,
        follows,
        stories,
        savedPostIds,
        currentView,
        selectedProfileUserId,
        selectedPostId,
        setCurrentView,
        openUserProfile,
        setSelectedPostId,
        login,
        register,
        logout,
        switchUser,
        updateProfile,
        updatePassword,
        createPost,
        editPost,
        deletePost,
        toggleSavePost,
        isSaved,
        toggleLike,
        hasLiked,
        getPostLikesCount,
        getPostComments,
        addComment,
        deleteComment,
        toggleFollow,
        isFollowing,
        getFollowers,
        getFollowing,
        getUserById,
        getProfileByUserId,
        getUserPosts,
        resetToDemoData,
      }}
    >
      {children}
    </SocialContext.Provider>
  );
};

export const useSocial = () => {
  const context = useContext(SocialContext);
  if (!context) {
    throw new Error('useSocial must be used within a SocialProvider');
  }
  return context;
};
