import { User, Profile, Post, Comment, Like, Follow, Story } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user-1',
    username: 'alexchen',
    email: 'alex.chen@example.com',
    fullName: 'Alex Chen',
    dateJoined: '2025-01-15T10:00:00Z',
  },
  {
    id: 'user-2',
    username: 'mayalin',
    email: 'maya.lin@example.com',
    fullName: 'Maya Lin',
    dateJoined: '2025-02-01T12:30:00Z',
  },
  {
    id: 'user-3',
    username: 'liamr',
    email: 'liam.rivera@example.com',
    fullName: 'Liam Rivera',
    dateJoined: '2025-02-14T08:15:00Z',
  },
  {
    id: 'user-4',
    username: 'sofiarossi',
    email: 'sofia.rossi@example.com',
    fullName: 'Sofia Rossi',
    dateJoined: '2025-03-01T14:45:00Z',
  },
  {
    id: 'user-5',
    username: 'elenavance',
    email: 'elena.vance@example.com',
    fullName: 'Elena Vance',
    dateJoined: '2025-03-10T16:20:00Z',
  },
];

export const INITIAL_PROFILES: Profile[] = [
  {
    id: 'prof-1',
    userId: 'user-1',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    bio: 'Photographer & coffee addict ☕️ Capturing hidden street corners and golden hour light.',
    website: 'https://alexchen.photos',
    location: 'San Francisco, CA',
    isVerified: true,
  },
  {
    id: 'prof-2',
    userId: 'user-2',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80',
    bio: 'UI/UX Designer & Creative coder 🎨 Crafting fluid digital experiences and modern minimal interfaces.',
    website: 'https://mayadesign.studio',
    location: 'Brooklyn, NY',
    isVerified: true,
  },
  {
    id: 'prof-3',
    userId: 'user-3',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    bio: 'Culinary storyteller & home chef 🍜 Tokyo street eats to artisan sourdough. Recipes & flavor hunts.',
    website: 'https://tablebyrivera.com',
    location: 'Austin, TX',
    isVerified: false,
  },
  {
    id: 'prof-4',
    userId: 'user-4',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
    bio: 'Architectural photographer 🏛️ Geometric symmetry, brutalist concrete, and morning shadows.',
    website: 'https://rossiarchitect.it',
    location: 'Milan, Italy',
    isVerified: true,
  },
  {
    id: 'prof-5',
    userId: 'user-5',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
    bio: 'Trail runner & marathon trainer 🏔️ Chasing ridge sunrises and mountain miles. Keep moving forward.',
    website: 'https://elenaruns.net',
    location: 'Boulder, CO',
    isVerified: false,
  },
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post-1',
    authorId: 'user-1',
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=85',
    filter: 'filter-clarendon',
    caption: 'Quiet dawn at Yosemite Valley. The valley was covered in early fog before the sun broke through the pines. Moments like this remind me why we travel. 🌲 #nature #photography #wanderlust',
    location: 'Yosemite National Park, California',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45 mins ago
  },
  {
    id: 'post-2',
    authorId: 'user-2',
    imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=85',
    filter: 'filter-vivid',
    caption: 'Desk workspace setup update 💻 Testing out the new mechanical split keyboard and matte display. Clean spaces lead to clear ideas. #workspace #minimalism #design',
    location: 'Brooklyn Studio, New York',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(), // 3 hours ago
  },
  {
    id: 'post-3',
    authorId: 'user-3',
    imageUrl: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=1200&q=85',
    filter: 'filter-warm',
    caption: 'Handcrafted spicy tonkotsu ramen with marinated egg, chashu, and scallions. Simmered the broth for 14 hours. Worth every single minute. 🍜 #foodie #ramen #homecooking',
    location: 'Austin Culinary Lab',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 7).toISOString(), // 7 hours ago
  },
  {
    id: 'post-4',
    authorId: 'user-4',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
    filter: 'filter-moon',
    caption: 'Minimalist curved spiral staircase in the modern art pavilion. The play of harsh shadows against textured lime plaster. #architecture #blackandwhite #monochrome',
    location: 'Fondazione Prada, Milan',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString(), // 22 hours ago
  },
  {
    id: 'post-5',
    authorId: 'user-5',
    imageUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=85',
    filter: 'filter-vintage',
    caption: 'First ridge summit of the spring season! High winds, crisp air, and 360-degree peak vistas. 18 miles on the trail today. 🥾 #trailrunning #colorado #mountains',
    location: 'Rocky Mountain National Park',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString(), // 1.5 days ago
  },
  {
    id: 'post-6',
    authorId: 'user-1',
    imageUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=85',
    filter: 'filter-retro',
    caption: 'Sunday morning pour over with Ethiopian natural process beans. Notes of peach and bergamot. The best ritual to kick off the day. ☕️ #coffeetime #specialtycoffee',
    location: 'Sightglass Coffee, SF',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 52).toISOString(),
  },
];

export const INITIAL_LIKES: Like[] = [
  { id: 'like-1', postId: 'post-1', userId: 'user-2', createdAt: new Date().toISOString() },
  { id: 'like-2', postId: 'post-1', userId: 'user-3', createdAt: new Date().toISOString() },
  { id: 'like-3', postId: 'post-1', userId: 'user-4', createdAt: new Date().toISOString() },
  { id: 'like-4', postId: 'post-2', userId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'like-5', postId: 'post-2', userId: 'user-3', createdAt: new Date().toISOString() },
  { id: 'like-6', postId: 'post-3', userId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'like-7', postId: 'post-3', userId: 'user-2', createdAt: new Date().toISOString() },
  { id: 'like-8', postId: 'post-3', userId: 'user-4', createdAt: new Date().toISOString() },
  { id: 'like-9', postId: 'post-4', userId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'like-10', postId: 'post-5', userId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'like-11', postId: 'post-5', userId: 'user-2', createdAt: new Date().toISOString() },
];

export const INITIAL_COMMENTS: Comment[] = [
  {
    id: 'comm-1',
    postId: 'post-1',
    authorId: 'user-2',
    text: 'That mist is breathtaking Alex! Which lens did you shoot this with?',
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
  {
    id: 'comm-2',
    postId: 'post-1',
    authorId: 'user-4',
    text: 'Composition is perfection. Truly serene.',
    createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
  },
  {
    id: 'comm-3',
    postId: 'post-2',
    authorId: 'user-1',
    text: 'Such a clean cable management setup! What monitor arm is that?',
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
  {
    id: 'comm-4',
    postId: 'post-3',
    authorId: 'user-5',
    text: 'I need this after a 20 mile run! Looks incredible Liam 🤤',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
  },
  {
    id: 'comm-5',
    postId: 'post-4',
    authorId: 'user-2',
    text: 'Brutalist perfection. Black and white suits this structure so well.',
    createdAt: new Date(Date.now() - 1000 * 60 * 600).toISOString(),
  },
];

export const INITIAL_FOLLOWS: Follow[] = [
  { id: 'f-1', followerId: 'user-1', followingId: 'user-2', createdAt: new Date().toISOString() },
  { id: 'f-2', followerId: 'user-1', followingId: 'user-3', createdAt: new Date().toISOString() },
  { id: 'f-3', followerId: 'user-2', followingId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'f-4', followerId: 'user-3', followingId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'f-5', followerId: 'user-4', followingId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'f-6', followerId: 'user-4', followingId: 'user-2', createdAt: new Date().toISOString() },
  { id: 'f-7', followerId: 'user-5', followingId: 'user-1', createdAt: new Date().toISOString() },
  { id: 'f-8', followerId: 'user-1', followingId: 'user-4', createdAt: new Date().toISOString() },
];

export const INITIAL_STORIES: Story[] = [
  {
    id: 'st-1',
    userId: 'user-2',
    imageUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80',
    caption: 'Color palette experiments for upcoming brand refresh 🎨',
    createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
  },
  {
    id: 'st-2',
    userId: 'user-3',
    imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    caption: 'Fresh farmer market haul this morning! 🌱',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
  },
  {
    id: 'st-3',
    userId: 'user-4',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80',
    caption: 'Shadow studies at noon 📐',
    createdAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
  },
  {
    id: 'st-4',
    userId: 'user-5',
    imageUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=600&q=80',
    caption: 'Packing trail essentials for the 50k weekend ⛰️',
    createdAt: new Date(Date.now() - 1000 * 60 * 420).toISOString(),
  },
];

export const PRESET_IMAGES = [
  {
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=85',
    label: 'Tropical Beach',
    category: 'Travel',
  },
  {
    url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=85',
    label: 'Misty Mountains',
    category: 'Nature',
  },
  {
    url: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=1200&q=85',
    label: 'Bistro Night',
    category: 'Food',
  },
  {
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=85',
    label: 'Glass Tower',
    category: 'Architecture',
  },
  {
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=85',
    label: 'Silicon Hardware',
    category: 'Tech',
  },
  {
    url: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=85',
    label: 'Web Coding',
    category: 'Design',
  },
];
