export interface User {
  id: string;
  username: string;
  email: string;
  fullName: string;
  password?: string;
  dateJoined: string;
}

export interface Profile {
  id: string;
  userId: string;
  avatarUrl: string;
  bio: string;
  website?: string;
  location?: string;
  isVerified?: boolean;
}

export interface Post {
  id: string;
  authorId: string;
  imageUrl: string;
  filter?: string;
  caption: string;
  location?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Like {
  id: string;
  postId: string;
  userId: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  text: string;
  createdAt: string;
}

export interface Follow {
  id: string;
  followerId: string;
  followingId: string;
  createdAt: string;
}

export interface Story {
  id: string;
  userId: string;
  imageUrl: string;
  filter?: string;
  caption?: string;
  createdAt: string;
}

export type PageView = 'home' | 'explore' | 'create' | 'profile' | 'edit-profile' | 'django-code' | 'auth';
