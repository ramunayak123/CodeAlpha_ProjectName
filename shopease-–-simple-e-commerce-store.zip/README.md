# ShopEase – Simple E-commerce Store
**CodeAlpha Full Stack Development Internship — Task 1 Submission**

An intuitive, responsive, production-ready Full Stack E-commerce web application featuring dynamic catalog browsing, real-time product search and category filtering, interactive shopping cart management, user authentication with bcrypt password security, and SQLite relational database order processing with automated inventory tracking.

---

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [Technology Stack](#technology-stack)
3. [Key Features & Capabilities](#key-features--capabilities)
4. [Database Architecture & Design](#database-architecture--design)
5. [Project Folder Structure](#project-folder-structure)
6. [REST API Documentation](#rest-api-documentation)
7. [Installation & Setup Instructions](#installation--setup-instructions)
8. [Step-by-Step Execution Guide](#step-by-step-execution-guide)
9. [Internship Demonstration & Video Recording Guide](#internship-demonstration--video-recording-guide)
10. [Internship Evaluation Summary](#internship-evaluation-summary)

---

## 1. Project Overview

ShopEase was designed and built as part of the **CodeAlpha Full Stack Development Internship (Task 1)**. The objective is to develop a functional e-commerce website where customers can:
- Explore and filter high-quality products across multiple categories.
- Examine individual product specifications and live stock indicators.
- Manage a shopping cart (add, increase, decrease, remove items, apply discount vouchers).
- Securely register and sign in with bcrypt-hashed credentials stored in SQLite.
- Seamlessly complete order checkout, decrementing inventory atomically in the database.
- Review past order receipts in their account order history.
- Inspect live SQLite tables through an embedded database inspector.

---

## 2. Technology Stack

- **Frontend:**
  - **React 19 & TypeScript:** Component-based UI with strong typing and state hooks.
  - **Tailwind CSS v4:** Modern, responsive styling with clean mobile, tablet, and desktop layouts.
  - **Lucide Icons:** Clean, minimalist iconography.
- **Backend:**
  - **Node.js & Express.js:** Robust RESTful API endpoints for auth, products, orders, and admin inspection.
  - **Bcrypt.js:** Industry-standard password hashing with cryptographic salt rounds.
  - **Vite:** Full-stack development middleware bridging frontend and backend on port 3000.
- **Database:**
  - **SQLite 3 (`better-sqlite3`):** Serverless, zero-configuration relational database with foreign keys, transactional integrity, and persistent file storage in `/data/shopease.sqlite`.

---

## 3. Key Features & Capabilities

### A. Home Page
- **Header & Navigation:** Responsive navbar with brand logo, live search bar, real-time cart badge, user profile menu, and one-click SQLite database inspector.
- **Hero Banner:** Eye-catching banner showcasing seasonal deals, trust badges (Free Shipping over $100, 100% Genuine, 30-Day Money Back, 24/7 Support), and interactive coupon code voucher (`SHOPEASE10`).
- **Category Filter Pills:** Instant filtering for All, Electronics, Gadgets, Fashion, and Home & Living.
- **Sorting Options:** Sort products by Featured, Price (Low to High), Price (High to Low), or Customer Ratings.
- **Product Cards:** Visual display with images, categories, ratings, prices, availability badges (In Stock, Low Stock, Out of Stock), Quick View, and Add to Cart buttons.

### B. Product Details View
- Full-screen modal display with high-resolution image.
- Comprehensive product description and key specifications.
- Live warehouse stock level indicator.
- Interactive quantity selector (+ / -) clamped to remaining warehouse inventory.
- Real-time stock warnings when items are low or out of stock.

### C. Shopping Cart Drawer
- Slide-out cart with distinct item count.
- Dynamic quantity adjustment with immediate price recalculation.
- Individual item removal and one-click "Clear All" capability.
- Automatic breakdown calculation: Subtotal, Shipping ($5.00 flat or FREE on orders over $100), Sales Tax (7%), and applied Promo Discounts.
- Working promo code support: Apply `SHOPEASE10` for an instant 10% discount.

### D. User Registration & Authentication
- Secure modal with "Sign In" and "Register Account" tabs.
- Validation for full name, email format, password length (minimum 6 characters), and password confirmation.
- Passwords securely hashed with `bcryptjs` before insertion into the SQLite database.
- Quick **Demo Autofill button** (`alex@shopease.com` / `demo1234`) for evaluation.
- Checkout restricted to registered and logged-in customers.

### E. Order Processing & Transactional Integrity
- Multi-step checkout review displaying customer shipping address form and payment method selection (Cash on Delivery, Credit/Debit Card, UPI / Instant Pay).
- SQLite atomic transactions: Verifies available stock, inserts the order into the `orders` table, records individual line items into `order_items`, and decrements stock in `products`.
- Generates a formatted, unique Order ID (e.g. `SE-261109-7K2X`).
- Order confirmation modal with printable receipt.
- "My Orders" customer portal listing previous orders, status badges, delivery destinations, and item breakdowns.

### F. Embedded SQLite Database Inspector
- Evaluators can open the **DB & Docs** inspector modal in the top navigation to view the raw tables (`users`, `products`, `orders`, `order_items`) in real time as actions occur in the UI.
- Includes a "Reset Stock" button to easily return the catalog to factory default numbers.

---

## 4. Database Architecture & Design

The relational database is stored in SQLite with foreign key enforcement enabled:

### 1. `users` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique user identifier |
| `full_name` | TEXT | NOT NULL | Customer full name |
| `email` | TEXT | UNIQUE NOT NULL | User email address |
| `password` | TEXT | NOT NULL | Salted bcrypt hash |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Registration timestamp |

### 2. `products` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique product ID |
| `name` | TEXT | NOT NULL | Product title |
| `description` | TEXT | NOT NULL | Detailed overview |
| `price` | REAL | NOT NULL | Unit price (USD) |
| `image` | TEXT | NOT NULL | High-resolution image URL |
| `category` | TEXT | NOT NULL | Product department |
| `stock` | INTEGER | NOT NULL | Warehouse quantity remaining |
| `rating` | REAL | DEFAULT 4.5 | Average review score |
| `reviews_count`| INTEGER | DEFAULT 120 | Number of customer reviews |
| `featured` | INTEGER | DEFAULT 0 | Promotion priority flag |

### 3. `orders` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | TEXT | PRIMARY KEY | Unique formatted Order ID |
| `user_id` | INTEGER | NOT NULL, FK -> users(id) | Associated customer ID |
| `user_name` | TEXT | NOT NULL | Customer name on record |
| `user_email` | TEXT | NOT NULL | Customer email on record |
| `total_amount` | REAL | NOT NULL | Final paid order total |
| `shipping_address`| TEXT | NOT NULL | Complete street address |
| `payment_method` | TEXT | NOT NULL | Selected payment gateway |
| `order_status` | TEXT | DEFAULT 'Confirmed' | Fulfillment status |
| `order_date` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order timestamp |

### 4. `order_items` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Line item record ID |
| `order_id` | TEXT | NOT NULL, FK -> orders(id) | Parent order ID |
| `product_id` | INTEGER | NOT NULL, FK -> products(id)| Ordered product ID |
| `product_name` | TEXT | NOT NULL | Name of product |
| `quantity` | INTEGER | NOT NULL | Quantity purchased |
| `product_price` | REAL | NOT NULL | Price at time of order |

---

## 5. Project Folder Structure

```
├── data/
│   └── shopease.sqlite          # SQLite persistent database file
├── server/
│   ├── db.ts                    # SQLite connection, schemas, and seeding logic
│   └── routes/
│       ├── auth.ts              # /api/auth/register & /api/auth/login endpoints
│       ├── products.ts          # /api/products listing & /api/products/reset
│       ├── orders.ts            # /api/orders transactional checkout & user orders
│       └── admin.ts             # /api/admin/db-inspector live database viewer
├── src/
│   ├── components/
│   │   ├── Navbar.tsx           # Navigation bar with search, cart, and auth
│   │   ├── HeroBanner.tsx       # Promotional banner, trust badges, category pills
│   │   ├── ProductCard.tsx      # Individual product cards with live stock tags
│   │   ├── ProductDetailsModal.tsx # Full product information and quantity selector
│   │   ├── CartDrawer.tsx       # Slide-out cart with promo code calculator
│   │   ├── AuthModal.tsx        # Registration and login modal with demo autofill
│   │   ├── CheckoutModal.tsx    # Shipping form, payment method, order submission
│   │   ├── OrderSuccessModal.tsx# Printable receipt and confirmation modal
│   │   ├── OrdersViewModal.tsx  # User previous purchases and tracking modal
│   │   ├── DatabaseInspectorModal.tsx # Live SQLite database table inspector
│   │   └── Footer.tsx           # Responsive footer and internship credits
│   ├── App.tsx                  # Core application logic & state integration
│   ├── index.css                # Tailwind CSS styles and font configurations
│   ├── main.tsx                 # React DOM client bootstrap
│   └── types.ts                 # TypeScript data contracts & models
├── index.html                   # HTML entry point with metadata and fonts
├── package.json                 # Dependencies and execution scripts
├── server.ts                    # Full-stack Node.js + Express entry point
├── tsconfig.json                # TypeScript compiler configuration
└── vite.config.ts               # Vite bundler configuration
```

---

## 6. REST API Documentation

| Method | Endpoint | Description | Status Codes |
|---|---|---|---|
| `GET` | `/api/products` | Retrieve catalog with optional `?search=`, `?category=`, and `?sort=` | `200 OK` |
| `GET` | `/api/products/categories` | Retrieve list of unique product categories | `200 OK` |
| `GET` | `/api/products/:id` | Fetch details for an individual product | `200 OK`, `404 Not Found` |
| `POST` | `/api/products/reset` | Resets products catalog and stock to initial factory defaults | `200 OK` |
| `POST` | `/api/auth/register` | Register new account, hash password with bcrypt, insert into DB | `201 Created`, `400`, `409` |
| `POST` | `/api/auth/login` | Validate credentials with bcrypt comparison and return user session | `200 OK`, `401 Unauthorized` |
| `GET` | `/api/auth/me/:userId` | Retrieve user profile by user ID | `200 OK`, `404 Not Found` |
| `POST` | `/api/orders` | Atomic transaction: checks stock, inserts order & items, decrements stock | `201 Created`, `400 Bad Request` |
| `GET` | `/api/orders/user/:userId`| Retrieve order history and line items for a specific user | `200 OK` |
| `GET` | `/api/admin/db-inspector` | Live introspection of all SQLite database tables, rows, and stats | `200 OK` |

---

## 7. Installation & Setup Instructions

### Prerequisites
- **Node.js** (v18 or higher recommended)
- **npm** (v8 or higher)

### Step 1: Clone or Extract the Project
```bash
git clone <repository_url>
cd shopease
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Run the Development Server
```bash
npm run dev
```
The server will start on `http://localhost:3000`. Open this URL in any web browser.

### Step 4: Build for Production (Optional)
```bash
npm run build
npm start
```

---

## 8. Step-by-Step Execution Guide

1. **Browse Products:** Open `http://localhost:3000`. You will see the home page banner, trust badges, and the 12 sample products across Electronics, Gadgets, Fashion, and Home & Living.
2. **Search & Filter:**
   - Type `"Headphones"` in the search bar to filter products in real time.
   - Click the `"Fashion"` category pill to isolate clothing and apparel.
   - Sort by `"Price: High to Low"`.
3. **View Product Details:** Click any product card or the `"View Details"` button to open the product modal with detailed specifications, stock indicator, and quantity picker.
4. **Add Items to Cart:** Click `"Add to Cart"`. The cart count badge on the navbar will update immediately.
5. **Manage Cart:**
   - Click the `"Cart"` button to open the cart drawer.
   - Adjust quantities with `+` and `-`. Notice the stock limits are respected.
   - Enter promo code `SHOPEASE10` and click `"Apply"` to enjoy an instant 10% discount.
6. **User Registration & Login:**
   - Click `"Sign In"` in the navbar.
   - To register: Switch to `"Register"`, enter your name, email, and password.
   - To test instantly: Click `"Autofill Demo"` (`alex@shopease.com` / `demo1234`) and click `"Sign In"`.
7. **Checkout & Order Placement:**
   - Click `"Proceed to Checkout"` in the cart drawer.
   - Confirm your shipping address and choose your payment method (e.g. Cash on Delivery).
   - Click `"Confirm & Place Order"`.
8. **View Receipt & Order History:**
   - View your confirmed order with its unique ID (e.g. `SE-261109-XXXX`).
   - Click `"Print Order Receipt"` or click your avatar and select `"My Orders"` to see your saved order history.
9. **Verify SQLite Database Storage:**
   - Click `"SQLite Inspector"` in the top banner or navbar.
   - Inspect the `orders` and `order_items` tables to observe your newly created record.
   - Inspect the `products` table to verify that the purchased item's stock was decremented!

---

## 9. Internship Demonstration & Video Recording Guide

When recording your demonstration video for CodeAlpha:

1. **Introduction (15-20 sec):** Introduce yourself, state your internship title (*CodeAlpha Full Stack Development Internship*), and specify Task 1: *ShopEase – Simple E-commerce Store*.
2. **Catalog & Search (30 sec):** Show the responsive homepage, search for a product (e.g. "Mechanical Keyboard"), and filter by category ("Electronics").
3. **Product Modal & Cart (30 sec):** Open a product details modal, increase quantity, add to cart, open the cart drawer, and apply promo code `SHOPEASE10`.
4. **Authentication (30 sec):** Demonstrate either registering a new user or logging in using the autofill demo credentials.
5. **Checkout & Order (30 sec):** Complete the checkout form, select payment, and click "Confirm & Place Order". Show the generated Order ID and receipt.
6. **Database Verification (30 sec):** Open the **SQLite Inspector** to prove backend database persistence: show the newly inserted row in `orders` and the reduced warehouse stock in `products`.
7. **Conclusion (15 sec):** Highlight the full-stack architecture (React, Express, SQLite, Bcrypt) and thank CodeAlpha.

---

## 10. Internship Evaluation Summary

| Requirement from Task 1 | Implementation Status | Evidence / Verification |
|---|---|---|
| **Attractive Homepage & Banner** | ✅ Complete | Gradient hero banner, category filters, and trust badges |
| **Product Listings & Details** | ✅ Complete | Cards with ratings, prices, stock badges, and detail modal |
| **Cart with Real-time Calculations** | ✅ Complete | Dynamic quantities, subtotal, shipping, tax, and promo discount |
| **User Registration & Login** | ✅ Complete | Form validation, secure bcrypt hashing, session persistence |
| **Order Processing & Unique Order ID** | ✅ Complete | Formatted unique IDs, summary review, receipt modal |
| **SQLite Relational Database** | ✅ Complete | `users`, `products`, `orders`, and `order_items` tables with live inspector |
| **Stock Management** | ✅ Complete | Transactional stock decrement upon order placement |
| **Responsive Design** | ✅ Complete | Seamless experience on mobile, tablet, and desktop viewports |
