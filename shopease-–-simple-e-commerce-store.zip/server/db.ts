import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure data directory exists
const dataDir = path.resolve(__dirname, '../../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'shopease.sqlite');
export const db = new Database(dbPath);

// Enable foreign keys
db.pragma('foreign_keys = ON');

export function initDatabase() {
  // Create tables as required by CodeAlpha Task 1
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      price REAL NOT NULL,
      image TEXT NOT NULL,
      category TEXT NOT NULL,
      stock INTEGER NOT NULL,
      rating REAL DEFAULT 4.5,
      reviews_count INTEGER DEFAULT 120,
      featured INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      user_name TEXT NOT NULL,
      user_email TEXT NOT NULL,
      total_amount REAL NOT NULL,
      shipping_address TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      order_status TEXT NOT NULL DEFAULT 'Confirmed',
      order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      product_price REAL NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );
  `);

  // Check if products need seeding
  const countRow = db.prepare('SELECT count(*) as count FROM products').get() as { count: number };
  if (countRow.count === 0) {
    seedDefaultProducts();
  }

  // Check if a demo user exists
  const userCount = db.prepare('SELECT count(*) as count FROM users').get() as { count: number };
  if (userCount.count === 0) {
    const hashedPassword = bcrypt.hashSync('demo1234', 10);
    db.prepare(`
      INSERT INTO users (full_name, email, password)
      VALUES (?, ?, ?)
    `).run('Alex Morgan (Demo)', 'alex@shopease.com', hashedPassword);
  }
}

export function seedDefaultProducts() {
  const deleteItems = db.prepare('DELETE FROM order_items');
  const deleteOrders = db.prepare('DELETE FROM orders');
  const deleteProducts = db.prepare('DELETE FROM products');
  
  deleteItems.run();
  deleteOrders.run();
  deleteProducts.run();

  const insertProduct = db.prepare(`
    INSERT INTO products (name, description, price, image, category, stock, rating, reviews_count, featured)
    VALUES (@name, @description, @price, @image, @category, @stock, @rating, @reviews_count, @featured)
  `);

  const initialProducts = [
    {
      name: 'AeroPulse Wireless Noise-Cancelling Headphones',
      description: 'Engineered for audio perfection with custom 40mm titanium drivers, 45-hour battery life, hybrid active noise cancellation, and plush memory foam earcups.',
      price: 199.99,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
      category: 'Electronics',
      stock: 18,
      rating: 4.8,
      reviews_count: 245,
      featured: 1
    },
    {
      name: 'TitanEdge Smart Fitness Watch Pro',
      description: 'Ultra-bright AMOLED display, continuous heart-rate & SpO2 tracking, 100+ workout modes, GPS navigation, and 7-day battery endurance in a stainless steel casing.',
      price: 149.50,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
      category: 'Gadgets',
      stock: 24,
      rating: 4.7,
      reviews_count: 189,
      featured: 1
    },
    {
      name: 'Zenith Minimalist Japanese Mechanical Keyboard',
      description: 'Tactile brown switches, PBT dye-sub keycaps, RGB backlighting with hot-swappable sockets and aircraft-grade aluminum top plate for gaming and coding.',
      price: 119.00,
      image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80',
      category: 'Electronics',
      stock: 15,
      rating: 4.9,
      reviews_count: 312,
      featured: 1
    },
    {
      name: 'Artisan Heritage Italian Leather Backpack',
      description: 'Handcrafted full-grain calfskin leather backpack featuring a padded 16-inch laptop compartment, water-resistant interior lining, and antiqued brass hardware.',
      price: 185.00,
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
      category: 'Fashion',
      stock: 12,
      rating: 4.9,
      reviews_count: 98,
      featured: 1
    },
    {
      name: 'Lumina Nordic Ceramic Pour-Over Coffee Set',
      description: 'Includes matte ceramic dripper, heat-resistant borosilicate glass server (600ml), and bamboo coaster. Brew barista-grade artisanal coffee at home.',
      price: 48.99,
      image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
      category: 'Home & Living',
      stock: 35,
      rating: 4.6,
      reviews_count: 156,
      featured: 0
    },
    {
      name: 'Vortex 4K Ultra-Wide Streaming Webcam',
      description: 'Crisp 4K UHD video at 60fps, dual AI noise-cancelling microphones, automatic light balance correction, and privacy shutter for conferencing and content creation.',
      price: 89.99,
      image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=800&q=80',
      category: 'Electronics',
      stock: 22,
      rating: 4.6,
      reviews_count: 142,
      featured: 0
    },
    {
      name: 'PureSilk Essential Linen Casual Shirt',
      description: 'Crafted from 100% sustainable European flax linen. Breathable, relaxed tailoring with mother-of-pearl buttons, ideal for warm climates and casual elegance.',
      price: 64.00,
      image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80',
      category: 'Fashion',
      stock: 28,
      rating: 4.5,
      reviews_count: 87,
      featured: 0
    },
    {
      name: 'AromaZen Ultrasonic Essential Oil Diffuser',
      description: 'Natural oak wood grain finish with ambient soft LED mood lighting, 400ml capacity, whisper-quiet operation, and auto shut-off for serene relaxation.',
      price: 39.50,
      image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=800&q=80',
      category: 'Home & Living',
      stock: 40,
      rating: 4.7,
      reviews_count: 210,
      featured: 0
    },
    {
      name: 'EchoPulse Mini Waterproof Bluetooth Speaker',
      description: 'IPX7 waterproof rating with deep punchy bass, 15W high-output driver, 14-hour playtime, and integrated carabiner strap for hiking and beach outings.',
      price: 54.99,
      image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=800&q=80',
      category: 'Gadgets',
      stock: 19,
      rating: 4.7,
      reviews_count: 178,
      featured: 0
    },
    {
      name: 'NovaTech Ergonomic Wireless Vertical Mouse',
      description: 'Scientifically designed 57-degree vertical angle reduces forearm strain, multi-device Bluetooth + 2.4G wireless switching, and silent click switches.',
      price: 42.00,
      image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=800&q=80',
      category: 'Electronics',
      stock: 26,
      rating: 4.8,
      reviews_count: 134,
      featured: 0
    },
    {
      name: 'EcoHydro Insulated Stainless Steel Tumbler (750ml)',
      description: 'Double-wall vacuum insulation keeps cold drinks iced for 24 hours and hot coffee steaming for 12 hours. Sweat-proof powder coat with leakproof straw lid.',
      price: 29.99,
      image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=80',
      category: 'Home & Living',
      stock: 50,
      rating: 4.9,
      reviews_count: 388,
      featured: 0
    },
    {
      name: 'Starlight Polarized Aviator Sunglasses',
      description: 'Classic lightweight titanium alloy frame with UV400 polarized scratch-resistant gradient lenses. Includes protective hardshell microfiber case.',
      price: 75.00,
      image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80',
      category: 'Fashion',
      stock: 30,
      rating: 4.6,
      reviews_count: 92,
      featured: 0
    }
  ];

  const insertMany = db.transaction((products) => {
    for (const p of products) {
      insertProduct.run(p);
    }
  });

  insertMany(initialProducts);
}
