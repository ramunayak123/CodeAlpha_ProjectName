import express, { Request, Response } from 'express';
import { db } from '../db.js';

const router = express.Router();

// GET /api/admin/db-inspector - Returns all tables and their live rows
router.get('/db-inspector', (req: Request, res: Response) => {
  try {
    const users = db.prepare('SELECT id, full_name, email, created_at FROM users ORDER BY id DESC').all();
    const products = db.prepare('SELECT id, name, category, price, stock, rating FROM products ORDER BY id ASC').all();
    const orders = db.prepare('SELECT id, user_id, user_name, user_email, total_amount, payment_method, order_status, order_date FROM orders ORDER BY order_date DESC').all();
    const orderItems = db.prepare('SELECT id, order_id, product_id, product_name, quantity, product_price FROM order_items ORDER BY id DESC').all();

    const stats = {
      totalUsers: users.length,
      totalProducts: products.length,
      totalOrders: orders.length,
      totalRevenue: orders.reduce((sum: number, o: any) => sum + (o.total_amount || 0), 0)
    };

    return res.json({
      database: 'shopease.sqlite (SQLite 3)',
      stats,
      tables: {
        users,
        products,
        orders,
        order_items: orderItems
      }
    });
  } catch (error: any) {
    console.error('Inspector error:', error);
    return res.status(500).json({ error: 'Failed to inspect database.' });
  }
});

export default router;
