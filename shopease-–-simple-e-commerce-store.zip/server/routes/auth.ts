import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../db.js';

const router = express.Router();

// POST /api/auth/register
router.post('/register', (req: Request, res: Response) => {
  try {
    const { fullName, email, password } = req.body;

    if (!fullName || !fullName.trim()) {
      return res.status(400).json({ error: 'Full name is required.' });
    }
    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: 'A valid email address is required.' });
    }
    if (!password || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const cleanEmail = email.trim().toLowerCase();

    // Check if user already exists
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(cleanEmail);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    // Hash password
    const saltRounds = 10;
    const hashedPassword = bcrypt.hashSync(password, saltRounds);

    // Insert user
    const insertStmt = db.prepare(`
      INSERT INTO users (full_name, email, password)
      VALUES (?, ?, ?)
    `);
    const result = insertStmt.run(fullName.trim(), cleanEmail, hashedPassword);
    const userId = Number(result.lastInsertRowid);

    const newUser = {
      id: userId,
      fullName: fullName.trim(),
      email: cleanEmail,
      createdAt: new Date().toISOString()
    };

    return res.status(201).json({
      message: 'Account created successfully! Welcome to ShopEase.',
      user: newUser
    });
  } catch (error: any) {
    console.error('Registration error:', error);
    return res.status(500).json({ error: 'Internal server error during registration.' });
  }
});

// POST /api/auth/login
router.post('/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Please provide both email and password.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(cleanEmail) as any;

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const userData = {
      id: user.id,
      fullName: user.full_name,
      email: user.email,
      createdAt: user.created_at
    };

    return res.json({
      message: 'Logged in successfully! Welcome back.',
      user: userData
    });
  } catch (error: any) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Internal server error during login.' });
  }
});

// GET /api/auth/me/:userId
router.get('/me/:userId', (req: Request, res: Response) => {
  try {
    const userId = Number(req.params.userId);
    const user = db.prepare('SELECT id, full_name, email, created_at FROM users WHERE id = ?').get(userId) as any;
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }
    return res.json({
      user: {
        id: user.id,
        fullName: user.full_name,
        email: user.email,
        createdAt: user.created_at
      }
    });
  } catch (error: any) {
    return res.status(500).json({ error: 'Error fetching user profile.' });
  }
});

export default router;
