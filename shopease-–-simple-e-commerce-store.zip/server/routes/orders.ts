import express, { Request, Response } from 'express';
import { db } from '../db.js';

const router = express.Router();

// Helper to generate readable unique order ID
function generateOrderId(): string {
  const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `SE-${dateStr}-${randomStr}`;
}

// POST /api/orders - Place a new order
router.post('/', (req: Request, res: Response) => {
  try {
    const { userId, items, shippingAddress, paymentMethod, discount = 0 } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'User ID is required to place an order.' });
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Your cart is empty. Please add items before checking out.' });
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.street || !shippingAddress.city || !shippingAddress.zipCode) {
      return res.status(400).json({ error: 'Please provide a complete shipping address.' });
    }

    // Verify user exists
    const user = db.prepare('SELECT id, full_name, email FROM users WHERE id = ?').get(userId) as any;
    if (!user) {
      return res.status(404).json({ error: 'User not found in system.' });
    }

    // SQLite Transaction: Check stock, create order, insert order items, decrement stock
    const placeOrderTransaction = db.transaction(() => {
      // 1. Verify stock and calculate subtotal
      let calculatedSubtotal = 0;
      const verifiedItems: { product: any; quantity: number }[] = [];

      for (const item of items) {
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId) as any;
        if (!product) {
          throw new Error(`Product with ID #${item.productId} was not found.`);
        }

        if (product.stock < item.quantity) {
          throw new Error(`Insufficient stock for "${product.name}". Only ${product.stock} units available.`);
        }

        calculatedSubtotal += product.price * item.quantity;
        verifiedItems.push({ product, quantity: item.quantity });
      }

      // Add standard flat shipping fee ($5.00) or free if > $100
      const shippingFee = calculatedSubtotal > 100 ? 0 : 5.00;
      const taxFee = Number((calculatedSubtotal * 0.07).toFixed(2));
      const totalAmount = Math.max(0, Number((calculatedSubtotal + shippingFee + taxFee - discount).toFixed(2)));

      const orderId = generateOrderId();
      const formattedAddress = `${shippingAddress.fullName}, ${shippingAddress.street}, ${shippingAddress.city}, ${shippingAddress.state || ''} ${shippingAddress.zipCode}, Phone: ${shippingAddress.phone || 'N/A'}`;

      // 2. Insert into orders table
      const insertOrder = db.prepare(`
        INSERT INTO orders (id, user_id, user_name, user_email, total_amount, shipping_address, payment_method, order_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Confirmed')
      `);
      insertOrder.run(orderId, user.id, user.full_name, user.email, totalAmount, formattedAddress, paymentMethod || 'Cash on Delivery');

      // 3. Insert order items & decrement stock
      const insertOrderItem = db.prepare(`
        INSERT INTO order_items (order_id, product_id, product_name, quantity, product_price)
        VALUES (?, ?, ?, ?, ?)
      `);
      const decrementStock = db.prepare(`
        UPDATE products SET stock = stock - ? WHERE id = ?
      `);

      for (const { product, quantity } of verifiedItems) {
        insertOrderItem.run(orderId, product.id, product.name, quantity, product.price);
        decrementStock.run(quantity, product.id);
      }

      return {
        orderId,
        totalAmount,
        subtotal: calculatedSubtotal,
        shippingFee,
        taxFee,
        discount,
        shippingAddress: formattedAddress,
        paymentMethod: paymentMethod || 'Cash on Delivery'
      };
    });

    const result = placeOrderTransaction();

    // Fetch full order with items to return
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(result.orderId) as any;
    const orderItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(result.orderId);

    return res.status(201).json({
      message: 'Order placed successfully!',
      order: {
        ...order,
        items: orderItems,
        breakdown: {
          subtotal: result.subtotal,
          shipping: result.shippingFee,
          tax: result.taxFee,
          discount: result.discount
        }
      }
    });
  } catch (error: any) {
    console.error('Order creation error:', error);
    return res.status(400).json({ error: error.message || 'Failed to place order.' });
  }
});

// GET /api/orders/user/:userId - Retrieve order history for logged-in user
router.get('/user/:userId', (req: Request, res: Response) => {
  try {
    const userId = Number(req.params.userId);
    const orders = db.prepare(`
      SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC
    `).all(userId) as any[];

    // Fetch order items for each order
    const getItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
    const fullOrders = orders.map(order => ({
      ...order,
      items: getItems.all(order.id)
    }));

    return res.json({ orders: fullOrders });
  } catch (error: any) {
    return res.status(500).json({ error: 'Failed to retrieve order history.' });
  }
});

// GET /api/orders/:orderId - Retrieve single order
router.get('/:orderId', (req: Request, res: Response) => {
  try {
    const orderId = req.params.orderId;
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;

    if (!order) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);
    return res.json({ order: { ...order, items } });
  } catch (error: any) {
    return res.status(500).json({ error: 'Failed to retrieve order details.' });
  }
});

export default router;
