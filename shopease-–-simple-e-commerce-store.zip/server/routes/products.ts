import express, { Request, Response } from 'express';
import { db, seedDefaultProducts } from '../db.js';

const router = express.Router();

// GET /api/products
router.get('/', (req: Request, res: Response) => {
  try {
    const { search, category, sort } = req.query;

    let query = 'SELECT * FROM products WHERE 1=1';
    const params: any[] = [];

    if (search && typeof search === 'string' && search.trim()) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      const term = `%${search.trim()}%`;
      params.push(term, term);
    }

    if (category && typeof category === 'string' && category !== 'All') {
      query += ' AND category = ?';
      params.push(category);
    }

    if (sort === 'price-low') {
      query += ' ORDER BY price ASC';
    } else if (sort === 'price-high') {
      query += ' ORDER BY price DESC';
    } else if (sort === 'rating') {
      query += ' ORDER BY rating DESC';
    } else {
      query += ' ORDER BY id ASC';
    }

    const products = db.prepare(query).all(...params);
    return res.json({ products });
  } catch (error: any) {
    console.error('Error fetching products:', error);
    return res.status(500).json({ error: 'Failed to retrieve products.' });
  }
});

// GET /api/products/categories
router.get('/categories', (req: Request, res: Response) => {
  try {
    const rows = db.prepare('SELECT DISTINCT category FROM products ORDER BY category ASC').all() as { category: string }[];
    const categories = ['All', ...rows.map(r => r.category)];
    return res.json({ categories });
  } catch (error: any) {
    return res.status(500).json({ error: 'Failed to retrieve categories.' });
  }
});

// GET /api/products/:id
router.get('/:id', (req: Request, res: Response) => {
  try {
    const id = Number(req.params.id);
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);

    if (!product) {
      return res.status(404).json({ error: 'Product not found.' });
    }

    return res.json({ product });
  } catch (error: any) {
    return res.status(500).json({ error: 'Error fetching product details.' });
  }
});

// POST /api/products/reset
router.post('/reset', (req: Request, res: Response) => {
  try {
    seedDefaultProducts();
    const products = db.prepare('SELECT * FROM products').all();
    return res.json({ message: 'Catalog and stock have been reset to factory defaults.', products });
  } catch (error: any) {
    return res.status(500).json({ error: 'Failed to reset product inventory.' });
  }
});

export default router;
