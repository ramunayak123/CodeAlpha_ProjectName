import React, { useState } from 'react';
import { X, CreditCard, Truck, ShieldCheck, MapPin, AlertCircle, ArrowRight, UserCheck, Lock } from 'lucide-react';
import { CartItem, ShippingAddress, User, Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  cart: CartItem[];
  discountAmount: number;
  promoCode: string;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onOpenAuth,
  cart,
  discountAmount,
  promoCode,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  const [address, setAddress] = useState<ShippingAddress>({
    fullName: currentUser?.fullName || '',
    street: '142 Market Street, Suite 4B',
    city: 'San Francisco',
    state: 'CA',
    zipCode: '94105',
    phone: '+1 (555) 349-2810',
  });

  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery' | 'Credit/Debit Card' | 'Instant UPI / Digital Pay'>('Cash on Delivery');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Calculations
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = subtotal > 100 || subtotal === 0 ? 0 : 5.00;
  const tax = Number((subtotal * 0.07).toFixed(2));
  const grandTotal = Math.max(0, subtotal + shipping + tax - discountAmount);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!address.fullName || !address.street || !address.city || !address.zipCode) {
      setErrorMessage('Please complete all required shipping fields.');
      return;
    }

    setSubmitting(true);
    setErrorMessage(null);

    try {
      const payload = {
        userId: currentUser.id,
        items: cart.map((item) => ({
          productId: item.product.id,
          quantity: item.quantity,
        })),
        shippingAddress: address,
        paymentMethod,
        discount: discountAmount,
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to place order.');
      }

      onOrderSuccess(data.order);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Error processing your order.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fadeIn">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 z-10 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                Secure Checkout & Order Placement
              </h2>
              <p className="text-xs text-slate-600">Review shipping, payment, and final totals</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-xl transition cursor-pointer"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
          {/* Guest Warning / Log In Requirement */}
          {!currentUser ? (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center space-y-4 my-6">
              <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 mx-auto flex items-center justify-center">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900">
                  Account Required to Place an Order
                </h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto mt-1">
                  As required by the e-commerce specifications, order placement is restricted to registered users to associate order IDs and maintain records.
                </p>
              </div>
              <button
                type="button"
                onClick={onOpenAuth}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer"
              >
                Sign In or Register Now
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmitOrder} className="space-y-6">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center space-x-2 text-xs text-red-700">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Logged in User Indicator */}
              <div className="flex items-center justify-between p-3 bg-indigo-50/80 border border-indigo-100 rounded-xl text-xs">
                <div className="flex items-center space-x-2 text-indigo-950 font-medium">
                  <UserCheck className="w-4 h-4 text-indigo-600" />
                  <span>
                    Placing order as <strong>{currentUser.fullName}</strong> ({currentUser.email})
                  </span>
                </div>
                <span className="text-indigo-600 text-[11px] font-bold">User #{currentUser.id}</span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left Column: Shipping & Payment details */}
                <div className="lg:col-span-7 space-y-5">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900 flex items-center space-x-2 mb-3">
                      <MapPin className="w-4 h-4 text-indigo-600" />
                      <span>Shipping Address</span>
                    </h3>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={address.fullName}
                          onChange={(e) => setAddress({ ...address, fullName: e.target.value })}
                          className="w-full bg-slate-50 text-slate-900 text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:border-indigo-500 focus:bg-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Street Address
                        </label>
                        <input
                          type="text"
                          required
                          value={address.street}
                          onChange={(e) => setAddress({ ...address, street: e.target.value })}
                          placeholder="House/Apartment # and street name"
                          className="w-full bg-slate-50 text-slate-900 text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:border-indigo-500 focus:bg-white"
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div className="col-span-1">
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            City
                          </label>
                          <input
                            type="text"
                            required
                            value={address.city}
                            onChange={(e) => setAddress({ ...address, city: e.target.value })}
                            className="w-full bg-slate-50 text-slate-900 text-xs sm:text-sm px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:border-indigo-500 focus:bg-white"
                          />
                        </div>

                        <div className="col-span-1">
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            State
                          </label>
                          <input
                            type="text"
                            value={address.state}
                            onChange={(e) => setAddress({ ...address, state: e.target.value })}
                            className="w-full bg-slate-50 text-slate-900 text-xs sm:text-sm px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:border-indigo-500 focus:bg-white"
                          />
                        </div>

                        <div className="col-span-1">
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            ZIP Code
                          </label>
                          <input
                            type="text"
                            required
                            value={address.zipCode}
                            onChange={(e) => setAddress({ ...address, zipCode: e.target.value })}
                            className="w-full bg-slate-50 text-slate-900 text-xs sm:text-sm px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:border-indigo-500 focus:bg-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Phone Number for Delivery Updates
                        </label>
                        <input
                          type="tel"
                          value={address.phone}
                          onChange={(e) => setAddress({ ...address, phone: e.target.value })}
                          className="w-full bg-slate-50 text-slate-900 text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:border-indigo-500 focus:bg-white"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Payment Method Selector */}
                  <div className="pt-3 border-t border-slate-200">
                    <h3 className="text-sm font-extrabold text-slate-900 flex items-center space-x-2 mb-3">
                      <CreditCard className="w-4 h-4 text-indigo-600" />
                      <span>Payment Method</span>
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                      {[
                        { id: 'Cash on Delivery', desc: 'Pay when delivered' },
                        { id: 'Credit/Debit Card', desc: 'Visa, Mastercard' },
                        { id: 'Instant UPI / Digital Pay', desc: 'Instant transfer' },
                      ].map((m) => (
                        <div
                          key={m.id}
                          onClick={() => setPaymentMethod(m.id as any)}
                          className={`p-3 rounded-xl border cursor-pointer transition flex flex-col justify-between ${
                            paymentMethod === m.id
                              ? 'border-indigo-600 bg-indigo-50/70 ring-1 ring-indigo-600 text-indigo-950 font-bold'
                              : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <span className="text-xs font-bold">{m.id}</span>
                          <span className="text-[11px] text-slate-600 mt-1">{m.desc}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Column: Order Summary */}
                <div className="lg:col-span-5 bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900 mb-3">
                      Order Summary ({cart.reduce((s, i) => s + i.quantity, 0)} items)
                    </h3>

                    <div className="max-h-48 overflow-y-auto space-y-2.5 divide-y divide-slate-200/70 pr-1">
                      {cart.map((item) => (
                        <div key={item.product.id} className="pt-2 first:pt-0 flex items-center space-x-3">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-12 h-12 object-cover rounded-lg border border-slate-200 shrink-0 bg-white"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-slate-800 truncate">
                              {item.product.name}
                            </p>
                            <p className="text-[11px] text-slate-600">
                              Qty: {item.quantity} × ${item.product.price.toFixed(2)}
                            </p>
                          </div>
                          <span className="text-xs font-bold text-slate-900 shrink-0">
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Breakdown */}
                    <div className="border-t border-slate-200 mt-4 pt-3 space-y-1.5 text-xs text-slate-600">
                      <div className="flex justify-between">
                        <span>Items Subtotal</span>
                        <span className="font-semibold text-slate-800">${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Estimated Shipping</span>
                        <span className="font-semibold text-slate-800">
                          {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Estimated Sales Tax (7%)</span>
                        <span className="font-semibold text-slate-800">${tax.toFixed(2)}</span>
                      </div>
                      {discountAmount > 0 && (
                        <div className="flex justify-between text-emerald-600 font-bold">
                          <span>Discount Applied ({promoCode})</span>
                          <span>-${discountAmount.toFixed(2)}</span>
                        </div>
                      )}

                      <div className="border-t border-slate-300 pt-2 flex justify-between items-baseline text-sm">
                        <span className="font-bold text-slate-900">Total Payable</span>
                        <span className="font-extrabold text-indigo-600 text-lg">
                          ${grandTotal.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 space-y-2">
                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-99 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 transition cursor-pointer disabled:opacity-50"
                    >
                      {submitting ? (
                        <span>Processing Order & Updating Stock...</span>
                      ) : (
                        <>
                          <span>Confirm & Place Order</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>

                    <div className="flex items-center justify-center space-x-1.5 text-[11px] text-slate-600">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Order will be recorded into SQLite database tables</span>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
