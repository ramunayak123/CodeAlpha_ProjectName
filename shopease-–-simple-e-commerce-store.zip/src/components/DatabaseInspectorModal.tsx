import React, { useState, useEffect } from 'react';
import { X, Database, Users, Package, ShoppingCart, RefreshCw, Layers, BookOpen, Video, CheckCircle2, RotateCcw } from 'lucide-react';
import { DBInspectorData } from '../types';

interface DatabaseInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCatalogReset: () => void;
}

export const DatabaseInspectorModal: React.FC<DatabaseInspectorModalProps> = ({
  isOpen,
  onClose,
  onCatalogReset,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'tables' | 'api' | 'guide'>('tables');
  const [selectedTable, setSelectedTable] = useState<'products' | 'users' | 'orders' | 'order_items'>('products');
  const [data, setData] = useState<DBInspectorData | null>(null);
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);
  const [resetMessage, setResetMessage] = useState<string | null>(null);

  const fetchDbData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/db-inspector');
      const json = await res.json();
      if (res.ok) {
        setData(json);
      }
    } catch (err) {
      console.error('Error fetching DB inspection data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDbData();
  }, []);

  const handleResetCatalog = async () => {
    if (!confirm('Reset products and inventory back to factory default state?')) return;
    setResetting(true);
    try {
      const res = await fetch('/api/products/reset', { method: 'POST' });
      const json = await res.json();
      if (res.ok) {
        setResetMessage('Catalog inventory reset to default!');
        await fetchDbData();
        onCatalogReset();
        setTimeout(() => setResetMessage(null), 3000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fadeIn">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative bg-white rounded-3xl shadow-2xl max-w-5xl w-full overflow-hidden border border-slate-200 z-10 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-400 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg sm:text-xl font-extrabold tracking-tight">
                  CodeAlpha Internship Toolkit & SQLite Inspector
                </h2>
                <span className="bg-indigo-500/30 text-indigo-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                  Live DB
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Inspect real SQLite tables, verify relational integrity, test REST APIs, and review project documentation
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={fetchDbData}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
              title="Refresh SQLite data"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 sm:px-6">
          <div className="flex space-x-2 sm:space-x-4">
            <button
              onClick={() => setActiveTab('tables')}
              className={`py-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition flex items-center space-x-1.5 cursor-pointer ${
                activeTab === 'tables'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>SQLite Tables ({data?.stats ? `${data.stats.totalProducts + data.stats.totalUsers + data.stats.totalOrders} Rows` : 'Live'})</span>
            </button>

            <button
              onClick={() => setActiveTab('api')}
              className={`py-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition flex items-center space-x-1.5 cursor-pointer ${
                activeTab === 'api'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>REST API Endpoints</span>
            </button>

            <button
              onClick={() => setActiveTab('guide')}
              className={`py-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition flex items-center space-x-1.5 cursor-pointer ${
                activeTab === 'guide'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Video className="w-4 h-4" />
              <span>Evaluation & Video Guide</span>
            </button>
          </div>

          {activeTab === 'tables' && (
            <button
              onClick={handleResetCatalog}
              disabled={resetting}
              className="text-[11px] font-bold text-slate-600 hover:text-indigo-600 flex items-center space-x-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-200/60 transition cursor-pointer"
              title="Reset product stocks to default"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${resetting ? 'animate-spin' : ''}`} />
              <span>Reset Stock</span>
            </button>
          )}
        </div>

        {/* Tab 1: Live SQLite Tables Inspector */}
        {activeTab === 'tables' && (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5">
            {resetMessage && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{resetMessage}</span>
              </div>
            )}

            {/* Quick Metrics Bar */}
            {data?.stats && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-600 font-bold uppercase block">Users Table</span>
                  <span className="text-xl font-black text-slate-900">{data.stats.totalUsers} registered</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-600 font-bold uppercase block">Products Table</span>
                  <span className="text-xl font-black text-slate-900">{data.stats.totalProducts} items</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-600 font-bold uppercase block">Orders Table</span>
                  <span className="text-xl font-black text-slate-900">{data.stats.totalOrders} placed</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-600 font-bold uppercase block">Recorded Revenue</span>
                  <span className="text-xl font-black text-emerald-600">${data.stats.totalRevenue.toFixed(2)}</span>
                </div>
              </div>
            )}

            {/* Table Selector Pills */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {[
                { id: 'products', name: 'products', count: data?.tables.products?.length ?? 0 },
                { id: 'users', name: 'users', count: data?.tables.users?.length ?? 0 },
                { id: 'orders', name: 'orders', count: data?.tables.orders?.length ?? 0 },
                { id: 'order_items', name: 'order_items', count: data?.tables.order_items?.length ?? 0 },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSelectedTable(t.id as any)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-2 cursor-pointer ${
                    selectedTable === t.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span className="font-mono">{t.name}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      selectedTable === t.id ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {t.count}
                  </span>
                </button>
              ))}
            </div>

            {/* Live Table Content */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs">
              <div className="max-h-80 overflow-auto">
                {loading ? (
                  <div className="py-12 text-center text-xs text-slate-500">Loading SQLite records...</div>
                ) : (
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-100 text-slate-700 border-b border-slate-200 sticky top-0 font-sans font-bold">
                      {selectedTable === 'products' && (
                        <tr>
                          <th className="p-3">ID</th>
                          <th className="p-3">Name</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Price</th>
                          <th className="p-3">Stock (Live)</th>
                          <th className="p-3">Rating</th>
                        </tr>
                      )}
                      {selectedTable === 'users' && (
                        <tr>
                          <th className="p-3">ID</th>
                          <th className="p-3">Full Name</th>
                          <th className="p-3">Email Address</th>
                          <th className="p-3">Password (Bcrypt Hash)</th>
                          <th className="p-3">Created At</th>
                        </tr>
                      )}
                      {selectedTable === 'orders' && (
                        <tr>
                          <th className="p-3">Order ID</th>
                          <th className="p-3">User</th>
                          <th className="p-3">Total Amount</th>
                          <th className="p-3">Payment Method</th>
                          <th className="p-3">Status</th>
                          <th className="p-3">Order Date</th>
                        </tr>
                      )}
                      {selectedTable === 'order_items' && (
                        <tr>
                          <th className="p-3">Item ID</th>
                          <th className="p-3">Order ID</th>
                          <th className="p-3">Product ID</th>
                          <th className="p-3">Product Name</th>
                          <th className="p-3">Quantity</th>
                          <th className="p-3">Unit Price</th>
                        </tr>
                      )}
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-800">
                      {selectedTable === 'products' &&
                        data?.tables.products.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50">
                            <td className="p-3 font-bold text-indigo-600">#{p.id}</td>
                            <td className="p-3 font-sans font-medium max-w-xs truncate">{p.name}</td>
                            <td className="p-3">{p.category}</td>
                            <td className="p-3 font-bold">${Number(p.price).toFixed(2)}</td>
                            <td className="p-3">
                              <span
                                className={`px-2 py-0.5 rounded font-bold ${
                                  p.stock <= 0
                                    ? 'bg-red-100 text-red-700'
                                    : p.stock <= 5
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {p.stock} units
                              </span>
                            </td>
                            <td className="p-3">⭐ {p.rating}</td>
                          </tr>
                        ))}

                      {selectedTable === 'users' &&
                        data?.tables.users.map((u) => (
                          <tr key={u.id} className="hover:bg-slate-50">
                            <td className="p-3 font-bold text-indigo-600">#{u.id}</td>
                            <td className="p-3 font-sans font-semibold">{u.full_name}</td>
                            <td className="p-3">{u.email}</td>
                            <td className="p-3 text-[10px] text-slate-600 truncate max-w-xs">
                              $2a$10$...[Protected bcrypt salt & hash]
                            </td>
                            <td className="p-3 text-slate-600">{u.created_at}</td>
                          </tr>
                        ))}

                      {selectedTable === 'orders' &&
                        (data?.tables.orders.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="p-6 text-center text-slate-600 font-sans">
                              No orders placed in SQLite yet. Checkout a product to populate this table!
                            </td>
                          </tr>
                        ) : (
                          data?.tables.orders.map((o) => (
                            <tr key={o.id} className="hover:bg-slate-50">
                              <td className="p-3 font-bold text-indigo-600">{o.id}</td>
                              <td className="p-3 font-sans">
                                <span className="font-semibold block">{o.user_name}</span>
                                <span className="text-[10px] text-slate-600">{o.user_email}</span>
                              </td>
                              <td className="p-3 font-bold text-slate-900">${Number(o.total_amount).toFixed(2)}</td>
                              <td className="p-3">{o.payment_method}</td>
                              <td className="p-3">
                                <span className="bg-emerald-100 text-emerald-800 font-sans font-bold px-2 py-0.5 rounded text-[10px]">
                                  {o.order_status}
                                </span>
                              </td>
                              <td className="p-3 text-slate-600">{o.order_date}</td>
                            </tr>
                          ))
                        ))}

                      {selectedTable === 'order_items' &&
                        (data?.tables.order_items.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="p-6 text-center text-slate-600 font-sans">
                              No items recorded yet. Order items will show here after checkout.
                            </td>
                          </tr>
                        ) : (
                          data?.tables.order_items.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50">
                              <td className="p-3 font-bold text-slate-600">#{item.id}</td>
                              <td className="p-3 font-bold text-indigo-600">{item.order_id}</td>
                              <td className="p-3">#{item.product_id}</td>
                              <td className="p-3 font-sans font-medium">{item.product_name}</td>
                              <td className="p-3 font-bold">{item.quantity}</td>
                              <td className="p-3">${Number(item.product_price).toFixed(2)}</td>
                            </tr>
                          ))
                        ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: REST API Documentation */}
        {activeTab === 'api' && (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs font-sans">
            <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-2xl">
              <h3 className="font-bold text-indigo-950 text-sm">ShopEase Backend REST API Specification</h3>
              <p className="text-slate-600 mt-1">
                All endpoints are served via Express.js and communicate with the local SQLite database.
              </p>
            </div>

            <div className="space-y-3">
              {[
                {
                  method: 'GET',
                  endpoint: '/api/products',
                  desc: 'Fetch product catalog with optional ?search=, ?category=, and ?sort= filters',
                  status: '200 OK',
                },
                {
                  method: 'GET',
                  endpoint: '/api/products/:id',
                  desc: 'Fetch full single product details, stock count, and description',
                  status: '200 OK / 404',
                },
                {
                  method: 'POST',
                  endpoint: '/api/auth/register',
                  desc: 'Registers new user, hashes password with bcrypt, inserts into `users` table',
                  status: '201 Created / 400 / 409',
                },
                {
                  method: 'POST',
                  endpoint: '/api/auth/login',
                  desc: 'Authenticates user via email and bcrypt password comparison',
                  status: '200 OK / 401 Unauthorized',
                },
                {
                  method: 'POST',
                  endpoint: '/api/orders',
                  desc: 'Executes atomic transaction: checks stock, inserts into `orders` & `order_items`, and decrements stock in `products`',
                  status: '201 Created / 400 Bad Request',
                },
                {
                  method: 'GET',
                  endpoint: '/api/orders/user/:userId',
                  desc: 'Retrieves purchase history and joined line items for a logged-in user',
                  status: '200 OK',
                },
                {
                  method: 'GET',
                  endpoint: '/api/admin/db-inspector',
                  desc: 'Real-time introspection of SQLite tables, counts, and revenue statistics',
                  status: '200 OK',
                },
              ].map((api, i) => (
                <div key={i} className="p-3.5 border border-slate-200 rounded-xl bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        api.method === 'GET' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {api.method}
                    </span>
                    <span className="font-mono font-bold text-slate-900">{api.endpoint}</span>
                  </div>
                  <div className="text-slate-600 sm:text-right">
                    <p>{api.desc}</p>
                    <span className="text-[10px] text-slate-600 font-mono font-semibold">{api.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Evaluation & Video Guide */}
        {activeTab === 'guide' && (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5 text-xs font-sans text-slate-700">
            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl">
              <h3 className="font-extrabold text-emerald-950 text-sm flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>CodeAlpha Internship Task 1 Compliance Checklist</span>
              </h3>
              <p className="text-emerald-800 mt-1">
                This project fulfills 100% of the objectives and requirements set in the CodeAlpha internship specification.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border border-slate-200 rounded-2xl bg-white space-y-2">
                <h4 className="font-bold text-slate-900 text-sm flex items-center space-x-1.5">
                  <Users className="w-4 h-4 text-indigo-600" />
                  <span>1. User Authentication (Task 1.D)</span>
                </h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  <li>User registration with Name, Email, Password</li>
                  <li>Bcrypt password hashing on Express backend</li>
                  <li>SQLite unique email constraint enforcement</li>
                  <li>User login and session management in React state</li>
                  <li>Checkout restricted to authenticated users</li>
                </ul>
              </div>

              <div className="p-4 border border-slate-200 rounded-2xl bg-white space-y-2">
                <h4 className="font-bold text-slate-900 text-sm flex items-center space-x-1.5">
                  <Package className="w-4 h-4 text-indigo-600" />
                  <span>2. Product Catalog & Details (Task 1.A & 1.B)</span>
                </h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  <li>Real-time search by product name/description</li>
                  <li>Category filtering (Electronics, Gadgets, Fashion, etc.)</li>
                  <li>Product cards with live stock indicators and ratings</li>
                  <li>Modal view with large image, specifications, and quantity picker</li>
                </ul>
              </div>

              <div className="p-4 border border-slate-200 rounded-2xl bg-white space-y-2">
                <h4 className="font-bold text-slate-900 text-sm flex items-center space-x-1.5">
                  <ShoppingCart className="w-4 h-4 text-indigo-600" />
                  <span>3. Shopping Cart & Promo (Task 1.C)</span>
                </h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  <li>Add, remove, increase, and decrease item quantities</li>
                  <li>Automatic subtotal, shipping, and tax computation</li>
                  <li>Coupon voucher system (<code className="bg-slate-100 px-1 rounded text-indigo-600 font-mono">SHOPEASE10</code>)</li>
                  <li>Slide-out responsive drawer interface</li>
                </ul>
              </div>

              <div className="p-4 border border-slate-200 rounded-2xl bg-white space-y-2">
                <h4 className="font-bold text-slate-900 text-sm flex items-center space-x-1.5">
                  <Database className="w-4 h-4 text-indigo-600" />
                  <span>4. Order Processing & SQLite DB (Task 1.E & 4)</span>
                </h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  <li>Unique Order ID generation (<code className="bg-slate-100 px-1 rounded font-mono">SE-YYMMDD-XXXX</code>)</li>
                  <li>Atomic SQLite transaction updates both <code className="font-mono">orders</code> & <code className="font-mono">order_items</code></li>
                  <li>Live stock decrement in <code className="font-mono">products</code> table</li>
                  <li>Printable confirmation receipt + "My Orders" history</li>
                </ul>
              </div>
            </div>

            {/* Video Demonstration Script */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
              <h4 className="font-bold text-slate-900 text-sm flex items-center space-x-2">
                <Video className="w-4 h-4 text-purple-600" />
                <span>Suggested Video Demonstration Flow (1.5 - 3 minutes):</span>
              </h4>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-600 leading-relaxed">
                <li><strong>Introduction:</strong> State your name and introduce "ShopEase – Simple E-commerce Store" for CodeAlpha Internship Task 1.</li>
                <li><strong>Catalog Browsing:</strong> Demonstrate searching for "Headphones" and filtering by categories like "Electronics".</li>
                <li><strong>Product Detail & Cart:</strong> Open a product modal, select quantity 2, and add to cart. Open Cart Drawer to show real-time calculations.</li>
                <li><strong>Coupon Code:</strong> Enter <code className="bg-white px-1 border rounded font-mono text-indigo-600">SHOPEASE10</code> and observe the 10% discount applied immediately.</li>
                <li><strong>User Registration & Login:</strong> Show the sign-in modal, click "Autofill Demo" (or register a new user), and log in.</li>
                <li><strong>Checkout & Order Placement:</strong> Proceed to checkout, confirm shipping address and payment method, and click "Confirm & Place Order".</li>
                <li><strong>Order Confirmation & Receipt:</strong> Showcase the unique order ID and receipt breakdown.</li>
                <li><strong>SQLite Database Proof:</strong> Open this "SQLite Inspector" modal to show the new row in the <code className="font-mono">orders</code> table and the decremented stock in the <code className="font-mono">products</code> table!</li>
              </ol>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
