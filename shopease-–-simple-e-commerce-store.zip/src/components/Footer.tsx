import React, { useState } from 'react';
import { ShoppingBag, Heart, Mail, Check, ShieldCheck, CreditCard, Lock, Sparkles } from 'lucide-react';

interface FooterProps {
  onOpenInspector: () => void;
  onSelectCategory: (category: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenInspector, onSelectCategory }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && email.includes('@')) {
      setSubscribed(true);
      setTimeout(() => {
        setEmail('');
        setSubscribed(false);
      }, 3000);
    }
  };

  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 mt-20">
      {/* Top Banner section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand & Internship Mission */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-500 flex items-center justify-center text-white shadow-md">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-white">
                Shop<span className="text-indigo-400">Ease</span>
              </span>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              ShopEase is an intuitive, full-stack e-commerce web platform developed as part of the <strong>CodeAlpha Full Stack Development Internship (Task 1)</strong>. Built with modern React, Express.js REST APIs, and SQLite database storage.
            </p>

            <div className="inline-flex items-center space-x-2 bg-slate-800/80 border border-slate-700/60 rounded-xl px-3 py-1.5 text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] font-medium">Internship Task 1: Complete Store Solution</span>
            </div>
          </div>

          {/* Quick Categories */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-3">
              Catalog
            </h4>
            <ul className="space-y-2">
              {['Electronics', 'Gadgets', 'Fashion', 'Home & Living'].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                      onSelectCategory(cat);
                    }}
                    className="hover:text-white transition cursor-pointer"
                  >
                    {cat}
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() => {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    onSelectCategory('All');
                  }}
                  className="hover:text-white transition cursor-pointer"
                >
                  All Products
                </button>
              </li>
            </ul>
          </div>

          {/* Internship & Developer Links */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-3">
              Developer & Tools
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={onOpenInspector}
                  className="text-indigo-400 hover:text-indigo-300 font-semibold transition cursor-pointer"
                >
                  SQLite Inspector
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenInspector}
                  className="hover:text-white transition cursor-pointer"
                >
                  REST API Docs
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenInspector}
                  className="hover:text-white transition cursor-pointer"
                >
                  Video Demo Script
                </button>
              </li>
              <li>
                <span className="text-slate-500">CodeAlpha Internship (Task 1)</span>
              </li>
            </ul>
          </div>

          {/* Newsletter Box */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-3">
              Stay Updated
            </h4>
            <p className="text-slate-400 text-xs mb-3">
              Get notified of seasonal discount sales and newly launched items.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full bg-slate-800 text-white text-xs px-3 py-2.5 rounded-xl border border-slate-700 focus:outline-hidden focus:border-indigo-500"
                />
                <Mail className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
              </div>
              <button
                type="submit"
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition text-xs flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                {subscribed ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Subscribed!</span>
                  </>
                ) : (
                  <span>Subscribe</span>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Bottom divider and copyright */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-center sm:text-left">
            © {new Date().getFullYear()} ShopEase – Simple E-commerce Store. Developed for CodeAlpha Full Stack Internship.
          </p>

          {/* Security & Payment Badges */}
          <div className="flex items-center space-x-4 text-slate-400 text-xs">
            <span className="flex items-center space-x-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>SSL Secured</span>
            </span>
            <span className="flex items-center space-x-1">
              <CreditCard className="w-4 h-4 text-indigo-400" />
              <span>Multiple Payments</span>
            </span>
            <span className="flex items-center space-x-1">
              <Lock className="w-4 h-4 text-blue-400" />
              <span>Bcrypt Protected</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
