import React from 'react';
import { Truck, ShieldCheck, RefreshCw, Headphones, Tag, Sparkles, Check } from 'lucide-react';

interface HeroBannerProps {
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onApplyPromoSnippet: (code: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  onApplyPromoSnippet,
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopyCode = () => {
    navigator.clipboard?.writeText('SHOPEASE10');
    setCopied(true);
    onApplyPromoSnippet('SHOPEASE10');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Main Hero Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white shadow-xl">
        {/* Background decorative ambient glows */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-indigo-500/20 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-20 w-80 h-80 rounded-full bg-blue-500/15 blur-3xl pointer-events-none" />

        <div className="relative px-6 py-10 sm:px-12 sm:py-14 md:py-16 max-w-5xl">
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 bg-indigo-500/20 backdrop-blur-md border border-indigo-400/30 px-3.5 py-1 rounded-full text-xs font-semibold text-indigo-200 mb-4">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>CodeAlpha Internship Showcase • Task 1</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Discover Quality Essentials, <br />
            <span className="bg-gradient-to-r from-indigo-300 via-blue-200 to-amber-200 bg-clip-text text-transparent">
              Delivered Seamlessly.
            </span>
          </h1>

          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl font-normal leading-relaxed">
            Welcome to ShopEase – your premier shopping destination. Browse our curated collection of electronics, gadgets, and lifestyle essentials with live stock tracking and instant checkout.
          </p>

          {/* Interactive Promo Coupon Voucher */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-2.5 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-2 text-sm">
              <Tag className="w-4 h-4 text-amber-300" />
              <span className="text-slate-200">Save 10% with code:</span>
              <span className="font-mono font-bold text-amber-300 tracking-wider">SHOPEASE10</span>
            </div>
            <button
              onClick={handleCopyCode}
              className="px-4 py-2 rounded-xl text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition flex items-center space-x-1.5 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  <span>Copied & Applied!</span>
                </>
              ) : (
                <span>Apply Code</span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Trust & Guarantee Badges */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-slate-900">Free Express Delivery</h4>
            <p className="text-[11px] sm:text-xs text-slate-600">On all orders over $100</p>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-slate-900">100% Genuine Products</h4>
            <p className="text-[11px] sm:text-xs text-slate-600">Directly sourced & verified</p>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <RefreshCw className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-slate-900">30-Day Easy Returns</h4>
            <p className="text-[11px] sm:text-xs text-slate-600">Hassle-free money back</p>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-slate-900">24/7 Customer Care</h4>
            <p className="text-[11px] sm:text-xs text-slate-600">Instant support via email</p>
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-600 mr-2 shrink-0">
          Categories:
        </span>
        {categories.map((cat) => {
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25 scale-102'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-slate-300'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>
    </div>
  );
};
