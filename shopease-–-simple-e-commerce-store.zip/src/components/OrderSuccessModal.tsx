import React from 'react';
import { CheckCircle2, Package, Printer, ArrowRight, Calendar, MapPin, CreditCard, ShieldCheck } from 'lucide-react';
import { Order } from '../types';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
  onViewAllOrders: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  onViewAllOrders,
}) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fadeIn">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200 z-10 flex flex-col max-h-[92vh]">
        {/* Success Header with celebration icon */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 p-6 sm:p-8 text-white text-center relative">
          <div className="w-16 h-16 rounded-3xl bg-white/20 backdrop-blur-md mx-auto flex items-center justify-center mb-3 shadow-inner">
            <CheckCircle2 className="w-9 h-9 text-white animate-scale" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Order Confirmed!
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-md mx-auto">
            Thank you for shopping with ShopEase. Your order has been registered in the database and is being processed for dispatch.
          </p>

          <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-md px-4 py-1.5 rounded-full text-xs font-bold mt-4">
            <span>Order ID:</span>
            <span className="font-mono text-amber-200 tracking-wider text-sm">{order.id}</span>
          </div>
        </div>

        {/* Order Details Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {/* Metadata Row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-600 block flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>Date</span>
              </span>
              <span className="font-bold text-slate-800 mt-0.5 block">
                {new Date(order.order_date).toLocaleDateString()}
              </span>
            </div>

            <div>
              <span className="text-slate-600 block flex items-center space-x-1">
                <CreditCard className="w-3.5 h-3.5" />
                <span>Payment</span>
              </span>
              <span className="font-bold text-slate-800 mt-0.5 block">
                {order.payment_method}
              </span>
            </div>

            <div className="col-span-2 sm:col-span-1">
              <span className="text-slate-600 block flex items-center space-x-1">
                <Package className="w-3.5 h-3.5" />
                <span>Status</span>
              </span>
              <span className="font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md inline-block mt-0.5">
                {order.order_status}
              </span>
            </div>
          </div>

          {/* Delivery Address */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
            <span className="text-slate-600 font-bold flex items-center space-x-1 mb-1">
              <MapPin className="w-3.5 h-3.5 text-indigo-600" />
              <span>Delivery Destination</span>
            </span>
            <p className="text-slate-800 font-medium leading-relaxed">
              {order.shipping_address}
            </p>
          </div>

          {/* Purchased Items List */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2.5">
              Purchased Items
            </h4>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-white">
              {order.items?.map((item) => (
                <div key={item.id} className="p-3.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-800">{item.product_name}</span>
                    <p className="text-slate-600">
                      Qty: {item.quantity} × ${item.product_price.toFixed(2)}
                    </p>
                  </div>
                  <span className="font-bold text-slate-900">
                    ${(item.quantity * item.product_price).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Total */}
          <div className="p-4 bg-indigo-50/70 border border-indigo-100 rounded-2xl flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-indigo-950 block">Grand Total Paid</span>
              <span className="text-[11px] text-indigo-700">Includes all taxes and delivery fees</span>
            </div>
            <span className="text-2xl font-black text-indigo-600">
              ${order.total_amount.toFixed(2)}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              onClick={handlePrint}
              className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center justify-center space-x-2 border border-slate-200 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Order Receipt</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onViewAllOrders();
              }}
              className="py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>View in My Orders</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="text-center">
            <button
              onClick={onClose}
              className="text-xs font-semibold text-slate-600 hover:text-slate-800 transition cursor-pointer"
            >
              Continue Browsing Products
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
