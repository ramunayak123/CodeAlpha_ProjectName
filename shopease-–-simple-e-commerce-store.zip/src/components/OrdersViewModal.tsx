import React, { useState, useEffect } from 'react';
import { X, Package, Calendar, MapPin, CreditCard, ChevronRight, RefreshCw, ShoppingBag } from 'lucide-react';
import { User, Order } from '../types';

interface OrdersViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onOpenAuth: () => void;
}

export const OrdersViewModal: React.FC<OrdersViewModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onOpenAuth,
}) => {
  if (!isOpen) return null;

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);

  const fetchOrders = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/orders/user/${currentUser.id}`);
      const data = await res.json();
      if (res.ok) {
        setOrders(data.orders || []);
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser) {
      fetchOrders();
    }
  }, [currentUser]);

  const toggleExpand = (orderId: string) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fadeIn">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative bg-white rounded-3xl shadow-2xl max-w-3xl w-full overflow-hidden border border-slate-200 z-10 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                Your Order History
              </h2>
              <p className="text-xs text-slate-600">
                Track previous purchases stored in the SQLite database
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={fetchOrders}
              className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-200/60 rounded-xl transition cursor-pointer"
              title="Refresh Orders"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-xl transition cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {!currentUser ? (
            <div className="text-center py-12">
              <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-800">Please sign in to view your orders</h3>
              <button
                onClick={onOpenAuth}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl"
              >
                Sign In
              </button>
            </div>
          ) : loading ? (
            <div className="py-16 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
              <p className="text-xs text-slate-600 font-medium">Fetching orders from SQLite...</p>
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-500 flex items-center justify-center mx-auto mb-3">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No orders placed yet</h3>
              <p className="text-xs text-slate-600 max-w-sm mx-auto mt-1">
                You haven't completed any purchases with this account. Browse our catalog and place your first test order!
              </p>
              <button
                onClick={onClose}
                className="mt-5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer"
              >
                Explore Products
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => {
                const isExpanded = expandedOrderId === order.id;
                return (
                  <div
                    key={order.id}
                    className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs transition hover:border-slate-300"
                  >
                    {/* Order summary bar */}
                    <div
                      onClick={() => toggleExpand(order.id)}
                      className="p-4 bg-slate-50/70 hover:bg-slate-100/70 flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none transition"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                          #
                        </div>
                        <div>
                          <span className="font-mono font-bold text-xs text-slate-900 block">
                            {order.id}
                          </span>
                          <span className="text-[11px] text-slate-600 flex items-center space-x-1 mt-0.5">
                            <Calendar className="w-3 h-3" />
                            <span>{new Date(order.order_date).toLocaleDateString()}</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <span className="text-xs font-bold text-emerald-700 bg-emerald-100/90 px-2.5 py-1 rounded-md">
                          {order.order_status}
                        </span>

                        <span className="text-sm font-extrabold text-slate-900">
                          ${order.total_amount.toFixed(2)}
                        </span>

                        <ChevronRight
                          className={`w-4 h-4 text-slate-400 transform transition-transform ${
                            isExpanded ? 'rotate-90' : ''
                          }`}
                        />
                      </div>
                    </div>

                    {/* Expanded details */}
                    {isExpanded && (
                      <div className="p-4 border-t border-slate-200 bg-white space-y-3 text-xs">
                        {/* Address & Payment */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl">
                          <div>
                            <span className="text-slate-600 font-bold flex items-center space-x-1 mb-0.5">
                              <MapPin className="w-3.5 h-3.5 text-indigo-600" />
                              <span>Shipped To:</span>
                            </span>
                            <p className="text-slate-800 leading-tight">{order.shipping_address}</p>
                          </div>
                          <div>
                            <span className="text-slate-600 font-bold flex items-center space-x-1 mb-0.5">
                              <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
                              <span>Payment:</span>
                            </span>
                            <p className="text-slate-800">{order.payment_method}</p>
                          </div>
                        </div>

                        {/* Order Items Table */}
                        <div>
                          <span className="font-bold text-slate-700 block mb-1.5">
                            Items in this Order ({order.items?.length || 0}):
                          </span>
                          <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100">
                            {order.items?.map((item) => (
                              <div
                                key={item.id}
                                className="p-2.5 flex items-center justify-between text-xs"
                              >
                                <span className="font-semibold text-slate-800">
                                  {item.product_name}
                                </span>
                                <div className="flex items-center space-x-3">
                                  <span className="text-slate-600">
                                    Qty: {item.quantity} × ${item.product_price.toFixed(2)}
                                  </span>
                                  <span className="font-bold text-slate-900 w-16 text-right">
                                    ${(item.quantity * item.product_price).toFixed(2)}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
