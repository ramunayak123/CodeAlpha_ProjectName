import React, { useState } from 'react';
import { X, Star, ShoppingBag, ShieldCheck, Truck, ArrowLeft, Plus, Minus, Check, AlertCircle } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  cartItemQuantity: number;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onAddToCart,
  cartItemQuantity,
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  const isOutOfStock = product.stock <= 0;
  const maxAvailable = Math.max(0, product.stock - cartItemQuantity);

  const handleIncrement = () => {
    if (quantity < maxAvailable) {
      setQuantity((prev) => prev + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1);
    }
  };

  const handleAddToCart = () => {
    if (quantity > 0 && quantity <= maxAvailable) {
      onAddToCart(product, quantity);
      setJustAdded(true);
      setTimeout(() => setJustAdded(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fadeIn">
      {/* Background click to dismiss */}
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 z-10 flex flex-col md:flex-row max-h-[92vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 bg-white/80 hover:bg-white text-slate-500 hover:text-slate-800 p-2 rounded-full shadow-md backdrop-blur-xs transition"
          aria-label="Close Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Large Product Image */}
        <div className="md:w-1/2 bg-slate-100 flex items-center justify-center relative p-6">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-72 sm:h-96 md:h-full object-cover rounded-2xl shadow-sm"
          />
          <div className="absolute top-6 left-6">
            <span className="bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-lg uppercase tracking-wider shadow-sm">
              {product.category}
            </span>
          </div>
        </div>

        {/* Right Column: Information, Specs & Actions */}
        <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
          <div>
            <button
              onClick={onClose}
              className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-600 hover:text-indigo-600 mb-3"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Catalog</span>
            </button>

            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-tight">
              {product.name}
            </h2>

            {/* Rating & Stock row */}
            <div className="flex items-center space-x-3 mt-2.5">
              <div className="flex items-center text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating)
                        ? 'fill-current'
                        : 'text-slate-200 fill-slate-200'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs font-bold text-slate-700">{product.rating.toFixed(1)}</span>
              <span className="text-xs text-slate-600">({product.reviews_count} customer reviews)</span>
            </div>

            {/* Price display */}
            <div className="mt-4 flex items-baseline space-x-3">
              <span className="text-3xl font-extrabold text-slate-900">
                ${product.price.toFixed(2)}
              </span>
              <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                Verified Price
              </span>
            </div>

            {/* Availability and Stock indicator */}
            <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-600">Availability:</span>
                {isOutOfStock ? (
                  <span className="text-red-600 font-bold flex items-center space-x-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Out of Stock</span>
                  </span>
                ) : (
                  <span className="text-emerald-700 font-bold flex items-center space-x-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>In Stock ({product.stock} units in warehouse)</span>
                  </span>
                )}
              </div>
              {cartItemQuantity > 0 && (
                <p className="text-[11px] text-indigo-600 mt-1 font-medium">
                  You already have {cartItemQuantity} of this item in your cart.
                </p>
              )}
            </div>

            {/* Product description */}
            <div className="mt-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                Product Overview
              </h4>
              <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Key benefits list */}
            <div className="mt-4 space-y-2 text-xs text-slate-600">
              <div className="flex items-center space-x-2">
                <Truck className="w-4 h-4 text-indigo-600" />
                <span>Fast express dispatch within 24 hours</span>
              </div>
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>1-Year Official Manufacturer Warranty Included</span>
              </div>
            </div>
          </div>

          {/* Quantity selector and Add To Cart */}
          <div className="pt-6 mt-6 border-t border-slate-200">
            {!isOutOfStock && maxAvailable > 0 ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Select Quantity:</span>
                  <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-xl border border-slate-200">
                    <button
                      onClick={handleDecrement}
                      disabled={quantity <= 1}
                      className="w-7 h-7 flex items-center justify-center rounded-lg bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 transition shadow-xs cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 text-center text-sm font-bold text-slate-800">
                      {quantity}
                    </span>
                    <button
                      onClick={handleIncrement}
                      disabled={quantity >= maxAvailable}
                      className="w-7 h-7 flex items-center justify-center rounded-lg bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 transition shadow-xs cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="w-full py-3.5 px-4 bg-indigo-600 hover:bg-indigo-700 active:scale-99 text-white font-bold rounded-xl shadow-md shadow-indigo-600/30 transition flex items-center justify-center space-x-2 cursor-pointer"
                >
                  {justAdded ? (
                    <>
                      <Check className="w-5 h-5 text-emerald-300" />
                      <span>Added to Shopping Cart!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-5 h-5" />
                      <span>Add to Cart – ${(product.price * quantity).toFixed(2)}</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              <button
                disabled
                className="w-full py-3.5 px-4 bg-slate-200 text-slate-500 font-bold rounded-xl cursor-not-allowed"
              >
                {isOutOfStock ? 'Item Currently Out of Stock' : 'Maximum Stock Already In Cart'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
