export interface User {
  id: number;
  fullName: string;
  email: string;
  createdAt?: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  stock: number;
  rating: number;
  reviews_count: number;
  featured: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ShippingAddress {
  fullName: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
}

export interface OrderItem {
  id: number;
  order_id: string;
  product_id: number;
  product_name: string;
  quantity: number;
  product_price: number;
}

export interface Order {
  id: string;
  user_id: number;
  user_name: string;
  user_email: string;
  total_amount: number;
  shipping_address: string;
  payment_method: string;
  order_status: string;
  order_date: string;
  items: OrderItem[];
  breakdown?: {
    subtotal: number;
    shipping: number;
    tax: number;
    discount: number;
  };
}

export interface DBStats {
  totalUsers: number;
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
}

export interface DBInspectorData {
  database: string;
  stats: DBStats;
  tables: {
    users: any[];
    products: any[];
    orders: any[];
    order_items: any[];
  };
}
